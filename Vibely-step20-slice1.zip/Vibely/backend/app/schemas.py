from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class MediaItem(BaseModel):
    id: str
    title: str
    uploader: str
    thumbnail_url: Optional[str] = None
    duration: Optional[str] = None
    source: str                       # display name, e.g. "Rumble"  (same as source_name)
    source_id: str = ""               # extractor id, e.g. "rumble"
    media_type: Optional[str] = "video"
    page_url: Optional[str] = None    # the video's own page; the app asks /api/stream for a fresh link
    media_url: Optional[str] = None   # always empty: stream links expire, so they are never stored
    source_name: Optional[str] = None
    published_date: Optional[str] = None


class SearchResponse(BaseModel):
    query: str
    items: List[MediaItem]
    message: str
    page: int = 1
    has_more: bool = False


class SourceInfo(BaseModel):
    id: str
    name: str
    enabled: bool = True
    description: str
    video_count: int = 0
    last_run: Optional[str] = None
    last_error: Optional[str] = None
    capabilities: Optional[Dict[str, Any]] = None   # see app/capabilities.py (Step 20)


class StreamResponse(BaseModel):
    source_id: str
    media_url: Optional[str] = None       # first (best) direct link, if any
    media_urls: List[str] = []            # all direct links, best first
    media_type: str = "video"
    embed_url: Optional[str] = None       # the site's own web player (WebView fallback)
    ttl_seconds: int = 1800               # how long the app may reuse this answer
