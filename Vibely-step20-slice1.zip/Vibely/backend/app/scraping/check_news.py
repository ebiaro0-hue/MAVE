"""Live check of the news sites: ``python -m app.scraping.check_news [source_id ...]`` (run it inside ``backend/``).

For each site it reads the listing, prints how many videos were found (and how long it took), then asks for the
playable link of the first video. Use it on a machine with Internet (your PC, or the Render shell) to see which of the
sites work today and which need their link pattern adjusted in ``sites_news.py`` after a website redesign.
The same information (last run, count, last error) is also shown by ``/api/sources`` once the server has scraped.
"""
from __future__ import annotations

import sys
import time

from app.scraping.sites import SITES_BY_ID
from app.scraping.sites_news import NEWS_SITES


def check(site) -> str:
    started = time.monotonic()
    try:
        entries = site.latest(1, 20)
    except Exception as exc:
        return f"FAIL   {site.source_id:<12} {str(exc)[:110]}"
    took = time.monotonic() - started
    line = f"OK     {site.source_id:<12} {len(entries):>2} videos in {took:4.1f}s"
    if not entries:
        return line + "  (empty)"
    first = entries[0]
    try:
        info = site.resolve_url(first.page_url)
        how = "file" if info.urls else "web player" if info.embed_url else "nothing"
    except Exception as exc:
        how = f"not playable by the site reader ({str(exc)[:60]}); yt-dlp is tried next"
    return f"{line}  | first: {first.title[:40]!r} -> {how}"


def main(argv: list) -> int:
    wanted = argv[1:]
    unknown = [w for w in wanted if w not in SITES_BY_ID]
    if unknown:
        print("Unknown source id(s):", ", ".join(unknown))
        print("Known news ids:", ", ".join(s.source_id for s in NEWS_SITES))
        return 2
    sites = [SITES_BY_ID[w] for w in wanted] if wanted else NEWS_SITES
    for site in sites:
        print(check(site), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
