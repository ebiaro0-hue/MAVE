"""One extractor per website: Stage 2 of the roadmap ("Building the Scraper").

Every site gives back :class:`Entry` objects in the same shape (title, thumbnail, source, page URL, date) and,
when asked, a *live* :class:`StreamInfo` (direct file links and/or the site's own web player).

Where a site offers a public API (PeerTube, Wikimedia Commons, Dailymotion, Odysee) that is used. Where it does
not (Pexels, Pixabay, Mixkit, Rumble, Vimeo) the page HTML is read with BeautifulSoup - politely: robots.txt is
checked first, requests are spaced out, and a site that blocks us is simply skipped. The parsing functions are pure
(text in, entries out) so they can be tested with saved pages and repaired quickly when a site changes its layout.

Video ids are the same ids the Android app uses on its own, so both sides can resolve each other's items.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Iterable, List, Optional, Tuple
from urllib.parse import quote, quote_plus, unquote, urljoin, urlparse

from bs4 import BeautifulSoup

from .models import Entry, StreamInfo, format_duration
from .polite import fetch_text

PER_PAGE = 20

DEFAULT_TOPICS = ["nature", "music", "science", "travel", "animals", "art", "technology", "documentary", "city", "food"]


class SiteError(Exception):
    """A video could not be found or played. The message is safe to show to the user."""


# ---------------------------------------------------------------------------------------------
# Small shared helpers
# ---------------------------------------------------------------------------------------------

def default_topic(page: int) -> str:
    """Sites without a "newest" feed are asked about a rotating topic instead."""
    return DEFAULT_TOPICS[(max(1, page) - 1) % len(DEFAULT_TOPICS)]


def quality_order(height: int) -> int:
    """Best quality up to 720p first, then the bigger ones (phones are happier with 720p)."""
    return 720 - height if 1 <= height <= 720 else 10_000 + height


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def title_from_slug(slug: str) -> str:
    s = slug.strip("/").rsplit("/", 1)[-1]
    s = re.sub(r"-\d+$", "", s).replace("-", " ").strip()
    return s[:1].upper() + s[1:]


def seconds_from_text(text: Optional[str]) -> Optional[int]:
    """'3:21' -> 201, '1:02:05' -> 3725."""
    if not text or not re.fullmatch(r"\d{1,2}(:\d{2}){1,2}", text.strip()):
        return None
    total = 0
    for part in text.strip().split(":"):
        total = total * 60 + int(part)
    return total or None


def _entry(source_id: str, source_name: str, video_id: str, title: str, uploader: str, thumbnail: Optional[str],
           seconds: Optional[int], page_url: str, duration_text: Optional[str] = None,
           published: Optional[str] = None) -> Entry:
    seconds = seconds if seconds and seconds > 0 else (seconds_from_text(duration_text))
    return Entry(
        source_id=source_id,
        source_name=source_name,
        video_id=video_id,
        title=(title or "").strip() or "Untitled",
        uploader=(uploader or "").strip() or source_name,
        thumbnail=thumbnail if thumbnail and thumbnail.startswith("http") else None,
        page_url=page_url,
        duration_seconds=seconds,
        duration_text=duration_text or format_duration(seconds),
        published_date=published or None,
    )


def _soup(html: str) -> BeautifulSoup:
    return BeautifulSoup(html, "html.parser")


def _abs(base: str, value: Optional[str]) -> str:
    return urljoin(base, value) if value else ""


def _first(*values: Optional[str]) -> Optional[str]:
    for v in values:
        if v:
            return v
    return None


def _linked_thumbnail(a, base: str) -> Optional[str]:
    img = a.select_one("img") or (a.parent.select_one("img") if a.parent else None)
    poster = a.select_one("video[poster]")
    return _first(
        _abs(base, img.get("src")) if img else None,
        _abs(base, img.get("data-src")) if img else None,
        _abs(base, poster.get("poster")) if poster else None,
    )


def _clean_path(href: str, prefix: str) -> str:
    path = href.split("?", 1)[0].split("#", 1)[0]
    return path[len(prefix):] if path.startswith(prefix) else path


def _unescape_json_urls(html: str) -> str:
    return html.replace("\\u002F", "/").replace("\\/", "/").replace("&amp;", "&")


def _distinct(items: Iterable[str]) -> List[str]:
    seen = set()
    out = []
    for item in items:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


class Site:
    """Base class. Subclasses fill in the four methods below."""

    source_id = ""
    name = ""
    description = ""
    hosts: Tuple[str, ...] = ()
    # Sites without a real "newest" feed are asked about a rotating topic; the scheduler rotates the topic.
    topic_based = False
    # False = the site can only give its first page (no usable paging), so the scheduler asks for page 1 only.
    paged = True
    # Sites with a small free quota are scraped only every N-th run (run 0 always scrapes).
    scrape_every = 1
    # True = try yt-dlp first for a direct file when the site itself only gives a web player.
    prefer_ytdlp = False

    def enabled(self) -> bool:
        """Sites that need a free key (or are switched off by default) say so here; they are skipped until ready."""
        return True

    def disabled_reason(self) -> Optional[str]:
        return None

    def search(self, query: str, page: int = 1, limit: int = PER_PAGE) -> List[Entry]:
        raise NotImplementedError

    def latest(self, page: int = 1, limit: int = PER_PAGE) -> List[Entry]:
        raise NotImplementedError

    def video_id_from_url(self, url: str) -> Optional[str]:
        return None

    def resolve(self, video_id: str) -> StreamInfo:
        raise NotImplementedError

    def resolve_url(self, url: str) -> StreamInfo:
        video_id = self.video_id_from_url(url)
        if not video_id:
            raise SiteError(f"That is not a {self.name} video address.")
        return self.resolve(video_id)


# ---------------------------------------------------------------------------------------------
# PeerTube (diode.zone) - official public API
# ---------------------------------------------------------------------------------------------

PEERTUBE_ID = re.compile(r"^[A-Za-z0-9-]{8,40}$")


def parse_peertube(text: str, host: str, source_id: str = "peertube", source_name: str = "PeerTube") -> List[Entry]:
    out = []
    for v in json.loads(text).get("data") or []:
        if not isinstance(v, dict) or v.get("isLive"):
            continue
        uuid = v.get("uuid") or ""
        if not PEERTUBE_ID.match(uuid):
            continue
        channel = (v.get("channel") or {}).get("displayName") or ""
        account = (v.get("account") or {}).get("displayName") or ""
        thumb_path = v.get("thumbnailPath") or ""
        out.append(_entry(
            source_id, source_name, uuid, v.get("name") or "", channel or account,
            f"https://{host}{thumb_path}" if thumb_path.startswith("/") else None,
            int(v.get("duration") or 0), v.get("url") or f"https://{host}/w/{uuid}",
            published=(v.get("publishedAt") or "")[:10],
        ))
    return out


def peertube_stream_urls(text: str) -> List[str]:
    root = json.loads(text)
    files = [f for f in (root.get("files") or []) if isinstance(f, dict) and str(f.get("fileUrl", "")).startswith("https://")]
    files.sort(key=lambda f: quality_order(int((f.get("resolution") or {}).get("id") or 0)))
    urls = [f["fileUrl"] for f in files]
    for playlist in root.get("streamingPlaylists") or []:
        link = (playlist or {}).get("playlistUrl") or ""
        if link.startswith("https://"):
            urls.append(link)
    return urls


class PeerTubeSite(Site):
    """One PeerTube server. Every server has the same official public API, so adding one is one line in
    ``PEERTUBE_INSTANCES`` (below); each server is its own site (own chip, own id)."""

    source_id = "peertube"
    name = "Diode Zone"
    description = "Open, federated video platform (diode.zone) - official public API"

    def __init__(self, host: str = "diode.zone", source_id: str = "peertube", name: str = "Diode Zone"):
        self.host = host
        self.hosts = (host,)
        self.source_id = source_id
        self.name = name
        self.description = f"Open, federated video platform ({host}) - official PeerTube API"

    def _list(self, path: str) -> List[Entry]:
        return parse_peertube(fetch_text(f"https://{self.host}{path}"), self.host, self.source_id, self.name)

    def search(self, query, page=1, limit=PER_PAGE):
        return self._list(f"/api/v1/search/videos?search={quote_plus(query)}&start={(page - 1) * limit}&count={limit}&nsfw=false&sort=-match")

    def latest(self, page=1, limit=PER_PAGE):
        return self._list(f"/api/v1/videos?start={(page - 1) * limit}&count={limit}&sort=-publishedAt&nsfw=false")

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/(?:w|videos/watch)/([A-Za-z0-9-]{8,40})", p.path)
        return m.group(1) if p.netloc == self.host and m else None

    def resolve(self, video_id):
        if not PEERTUBE_ID.match(video_id):
            raise SiteError("Invalid PeerTube video.")
        urls = peertube_stream_urls(fetch_text(f"https://{self.host}/api/v1/videos/{video_id}"))
        return StreamInfo(urls=urls, embed_url=f"https://{self.host}/videos/embed/{video_id}?autoplay=1")


# ---------------------------------------------------------------------------------------------
# Wikimedia Commons - official MediaWiki API, direct .webm/.mp4 files
# ---------------------------------------------------------------------------------------------

def parse_wikimedia(text: str) -> List[Entry]:
    pages = ((json.loads(text).get("query") or {}).get("pages")) or {}
    entries = sorted((p for p in pages.values() if isinstance(p, dict)), key=lambda p: int(p.get("index") or 0))
    out = []
    for p in entries:
        title = p.get("title") or ""
        infos = p.get("imageinfo") or []
        info = infos[0] if infos else None
        if not info:
            continue
        # The Android player handles webm/mp4; Ogg Theora (.ogv) is skipped.
        if info.get("mime") not in ("video/webm", "video/mp4") or not str(info.get("url", "")).startswith("https://"):
            continue
        artist_html = (((info.get("extmetadata") or {}).get("Artist") or {}).get("value")) or ""
        artist = _soup(artist_html).get_text(" ", strip=True)
        stem = title[5:] if title.startswith("File:") else title
        stem = stem.rpartition(".")[0] or stem
        out.append(_entry(
            "wikimedia", "Wikimedia Commons", title, stem.replace("_", " "), artist, info.get("thumburl"),
            None, "https://commons.wikimedia.org/wiki/" + quote(title.replace(" ", "_"), safe=":"),
        ))
    return out


class WikimediaSite(Site):
    source_id = "wikimedia"
    name = "Wikimedia Commons"
    description = "Free-licensed videos from Wikipedia's media library - official MediaWiki API"
    hosts = ("commons.wikimedia.org",)
    api = "https://commons.wikimedia.org/w/api.php"

    def _page(self, search: str, page: int, sort: str, limit: int) -> List[Entry]:
        url = (f"{self.api}?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit={limit}"
               f"&gsroffset={(page - 1) * limit}&gsrsort={sort}&gsrsearch={quote_plus(search + ' filetype:video')}"
               f"&prop=imageinfo&iiprop={quote_plus('url|mime|extmetadata')}&iiurlwidth=480&iiextmetadatafilter=Artist")
        return parse_wikimedia(fetch_text(url))

    def search(self, query, page=1, limit=PER_PAGE):
        return self._page(query, page, "relevance", limit)

    def latest(self, page=1, limit=PER_PAGE):
        return self._page("", page, "create_timestamp_desc", limit)

    def video_id_from_url(self, url):
        p = urlparse(url)
        if p.netloc not in self.hosts or not p.path.startswith("/wiki/File:"):
            return None
        return unquote(p.path[len("/wiki/"):]).replace("_", " ")

    def resolve(self, video_id):
        url = f"{self.api}?action=query&format=json&prop=imageinfo&iiprop={quote_plus('url|mime')}&titles={quote_plus(video_id)}"
        pages = ((json.loads(fetch_text(url)).get("query") or {}).get("pages")) or {}
        first = next(iter(pages.values()), None) or {}
        infos = first.get("imageinfo") or [{}]
        link = infos[0].get("url", "")
        if not link.startswith("https://") or infos[0].get("mime") not in ("video/webm", "video/mp4"):
            raise SiteError("This Wikimedia video has no playable file.")
        return StreamInfo(urls=[link])


# ---------------------------------------------------------------------------------------------
# Pexels / Pixabay / Mixkit - free stock video, web scraping (no API key needed)
# ---------------------------------------------------------------------------------------------

PEXELS_VIDEO = re.compile(r"^/video/([a-z0-9-]+-\d+)/?$")
PEXELS_MP4 = re.compile(r"""https://(?:videos\.pexels\.com/video-files|player\.vimeo\.com/external)/[^"'\s<>\\]+?\.mp4[^"'\s<>\\]*""")
PIXABAY_VIDEO = re.compile(r"^/videos/([a-z0-9-]+-\d+)/?$")
PIXABAY_MP4 = re.compile(r"""https://cdn\.pixabay\.com/video/[^"'\s<>\\]+?\.mp4""")
MIXKIT_ITEM = re.compile(r"^/free-stock-video/([a-z0-9-]+-\d+)/?$")
MIXKIT_MP4 = re.compile(r"""https?://assets\.mixkit\.co/[^"'\s<>\\]+\.mp4""")


def _parse_stock_listing(html: str, base: str, prefix: str, pattern, source_id: str, name: str, page_fmt: str) -> List[Entry]:
    seen: dict = {}
    for a in _soup(html).select("a[href]"):
        m = pattern.match(_clean_path(a.get("href", ""), prefix))
        if not m or m.group(1) in seen:
            continue
        vid = m.group(1)
        seen[vid] = _entry(source_id, name, vid, title_from_slug(vid), name, _linked_thumbnail(a, base), None, page_fmt.format(id=vid))
    return list(seen.values())


def parse_pexels_page(html: str) -> List[Entry]:
    return _parse_stock_listing(html, "https://www.pexels.com/", "https://www.pexels.com", PEXELS_VIDEO,
                                "pexels", "Pexels", "https://www.pexels.com/video/{id}/")


def parse_pixabay_page(html: str) -> List[Entry]:
    return _parse_stock_listing(html, "https://pixabay.com/", "https://pixabay.com", PIXABAY_VIDEO,
                                "pixabay", "Pixabay", "https://pixabay.com/videos/{id}/")


def parse_mixkit(html: str) -> List[Entry]:
    return _parse_stock_listing(html, "https://mixkit.co/", "https://mixkit.co", MIXKIT_ITEM,
                                "mixkit", "Mixkit", "https://mixkit.co/free-stock-video/{id}/")


def extract_pexels_mp4(html: str) -> List[str]:
    def rank(u: str) -> int:
        if "1280" in u or "720" in u or ".hd." in u:
            return 0
        if "960" in u or "640" in u or ".sd." in u:
            return 1
        if "1920" in u or "1080" in u:
            return 2
        return 3
    return sorted(_distinct(m.group(0) for m in PEXELS_MP4.finditer(_unescape_json_urls(html))), key=rank)


def extract_pixabay_mp4(html: str) -> List[str]:
    def rank(u: str) -> int:
        return 0 if "medium" in u else 1 if "small" in u else 2 if "large" in u else 3
    return sorted(_distinct(m.group(0) for m in PIXABAY_MP4.finditer(_unescape_json_urls(html))), key=rank)


def extract_mixkit_mp4(html: str) -> List[str]:
    def rank(u: str) -> int:
        return 0 if "720" in u else 1 if "1080" in u else 2 if "480" in u else 3
    return sorted(_distinct(m.group(0).replace("\\/", "/") for m in MIXKIT_MP4.finditer(html)), key=rank)


class _StockSite(Site):
    """Shared behaviour of the three stock-footage sites."""

    topic_based = True
    search_url = ""      # contains {slug} and {page}
    video_url = ""       # contains {id}
    id_pattern = re.compile(r"^[a-z0-9-]*\d+$")
    _parse = staticmethod(lambda html: [])
    _extract = staticmethod(lambda html: [])
    path_pattern = PEXELS_VIDEO

    def search(self, query, page=1, limit=PER_PAGE):
        slug = slugify(query)
        if not slug:
            return []
        return self._parse(fetch_text(self.search_url.format(slug=slug, page=page), scrape=True))[:limit]

    def latest(self, page=1, limit=PER_PAGE):
        return self.search(default_topic(page), 1, limit)

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = self.path_pattern.match(p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not self.id_pattern.match(video_id):
            raise SiteError(f"Invalid {self.name} video.")
        urls = self._extract(fetch_text(self.video_url.format(id=video_id), scrape=True))
        if not urls:
            raise SiteError(f"Could not find the video file on {self.name}. Tap Retry or try another video.")
        return StreamInfo(urls=urls)


class PexelsSite(_StockSite):
    source_id = "pexels"
    name = "Pexels"
    description = "Free stock video clips (web page reading)"
    hosts = ("www.pexels.com", "pexels.com")
    search_url = "https://www.pexels.com/search/videos/{slug}/?page={page}"
    video_url = "https://www.pexels.com/video/{id}/"
    path_pattern = PEXELS_VIDEO
    _parse = staticmethod(parse_pexels_page)
    _extract = staticmethod(extract_pexels_mp4)


class PixabaySite(_StockSite):
    source_id = "pixabay"
    name = "Pixabay"
    description = "Free stock video clips (web page reading)"
    hosts = ("pixabay.com", "www.pixabay.com")
    search_url = "https://pixabay.com/videos/search/{slug}/?pagi={page}"
    video_url = "https://pixabay.com/videos/{id}/"
    path_pattern = PIXABAY_VIDEO
    _parse = staticmethod(parse_pixabay_page)
    _extract = staticmethod(extract_pixabay_mp4)


class MixkitSite(_StockSite):
    source_id = "mixkit"
    name = "Mixkit"
    description = "Free stock video clips (web page reading)"
    hosts = ("mixkit.co", "www.mixkit.co")
    search_url = "https://mixkit.co/free-stock-video/{slug}/?page={page}"
    video_url = "https://mixkit.co/free-stock-video/{id}/"
    id_pattern = re.compile(r"^[a-z0-9-]+$")
    path_pattern = re.compile(r"^/free-stock-video/([a-z0-9-]+-\d+)/?$")
    _parse = staticmethod(parse_mixkit)
    _extract = staticmethod(extract_mixkit_mp4)
    topic_based = False

    def latest(self, page=1, limit=PER_PAGE):
        return parse_mixkit(fetch_text(f"https://mixkit.co/free-stock-video/?page={page}", scrape=True))[:limit]


# ---------------------------------------------------------------------------------------------
# Rumble - web scraping: listing page -> embed id -> embedJS gives mp4 links when available
# ---------------------------------------------------------------------------------------------

RUMBLE_LINK = re.compile(r"^/(v[a-z0-9]{4,}-[^/\s]*)\.html$")
RUMBLE_EMBED = re.compile(r"https://rumble\.com/embed/([0-9a-z]+)/?")
RUMBLE_ID = re.compile(r"^v[a-z0-9]{4,}-[^/\s]*$")


def _closest_card(a):
    for tag in [a, *a.parents]:
        classes = set(tag.get("class") or []) if hasattr(tag, "get") else set()
        if "videostream" in classes or "video-listing-entry" in classes or getattr(tag, "name", "") == "li":
            return tag
    return a.parent or a


def parse_rumble(html: str) -> List[Entry]:
    seen: dict = {}
    for a in _soup(html).select("a[href]"):
        m = RUMBLE_LINK.match(_clean_path(a.get("href", ""), "https://rumble.com").split("?", 1)[0])
        if not m or m.group(1) in seen:
            continue
        vid = m.group(1)
        card = _closest_card(a)
        h3 = card.select_one("h3")
        title = (h3.get_text(" ", strip=True) if h3 else "") or a.get("title", "") or title_from_slug(vid.split("-", 1)[-1])
        img = card.select_one("img")
        badge = card.select_one(".videostream__badge, [class*=duration]")
        duration = badge.get_text(strip=True) if badge else None
        duration = duration if duration and re.fullmatch(r"\d{1,2}(:\d{2}){1,2}", duration) else None
        address = card.select_one("address")
        seen[vid] = _entry("rumble", "Rumble", vid, title, address.get_text(" ", strip=True) if address else "",
                           _abs("https://rumble.com/", img.get("src")) if img else None, None,
                           f"https://rumble.com/{vid}.html", duration_text=duration)
    return list(seen.values())


def rumble_mp4_urls(text: str) -> List[str]:
    root = json.loads(text)
    found: List[Tuple[int, str]] = []
    for key in ("ua", "u"):
        mp4 = (root.get(key) or {}).get("mp4") if isinstance(root.get(key), dict) else None
        if not isinstance(mp4, dict):
            continue
        single = mp4.get("url")
        if isinstance(single, str) and single.startswith("https://"):
            found.append((int((mp4.get("meta") or {}).get("h") or 0), single))
        for k, e in mp4.items():
            if isinstance(e, dict) and str(e.get("url", "")).startswith("https://"):
                height = int(k) if str(k).isdigit() else int((e.get("meta") or {}).get("h") or 0)
                found.append((height, e["url"]))
    found.sort(key=lambda pair: quality_order(pair[0]))
    return _distinct(url for _, url in found)


class RumbleSite(Site):
    source_id = "rumble"
    name = "Rumble"
    description = "Video platform (web page reading; plays in its own web player when there is no file)"
    hosts = ("rumble.com", "www.rumble.com")
    topic_based = True

    def _list(self, query: str, page: int, newest: bool, limit: int) -> List[Entry]:
        url = f"https://rumble.com/search/video?q={quote_plus(query)}&page={page}" + ("&sort=date" if newest else "")
        return parse_rumble(fetch_text(url, scrape=True))[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        return self._list(query, page, False, limit)

    def latest(self, page=1, limit=PER_PAGE):
        return self._list(default_topic(page), 1, True, limit)

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = RUMBLE_LINK.match(p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not RUMBLE_ID.match(video_id):
            raise SiteError("Invalid Rumble video.")
        m = RUMBLE_EMBED.search(fetch_text(f"https://rumble.com/{video_id}.html", scrape=True))
        if not m:
            raise SiteError("Could not find the Rumble player for this video.")
        embed_id = m.group(1)
        try:
            urls = rumble_mp4_urls(fetch_text(f"https://rumble.com/embedJS/u3/?request=video&ver=2&v={embed_id}", scrape=True))
        except Exception:
            urls = []  # the web player below still works
        return StreamInfo(urls=urls, embed_url=f"https://rumble.com/embed/{embed_id}/")


# ---------------------------------------------------------------------------------------------
# Odysee - public search (lighthouse) + LBRY resolve API
# ---------------------------------------------------------------------------------------------

ODYSEE_API = "https://api.na-backend.odysee.com/api/v1/proxy?m=resolve"
CLAIM_ID = re.compile(r"^[0-9a-f]{40}$")


def parse_odysee_resolve(text: str) -> List[Entry]:
    out = []
    for c in ((json.loads(text).get("result")) or {}).values():
        if not isinstance(c, dict):
            continue
        claim_id, name = c.get("claim_id") or "", c.get("name") or ""
        value = c.get("value")
        if not CLAIM_ID.match(claim_id) or not name or not isinstance(value, dict):
            continue
        channel = c.get("signing_channel") or {}
        uploader = ((channel.get("value") or {}).get("title")) or channel.get("name") or ""
        out.append(_entry(
            "odysee", "Odysee", f"{claim_id}:{name}", value.get("title") or name, uploader,
            (value.get("thumbnail") or {}).get("url"), int((value.get("video") or {}).get("duration") or 0),
            f"https://odysee.com/{name}:{claim_id[:6]}",
        ))
    return out


def odysee_stream_url(name: str, claim_id: str, sd_hash: str) -> str:
    return f"https://player.odycdn.com/api/v3/streams/free/{quote(name, safe='')}/{claim_id}/{sd_hash[:6]}.mp4"


def odysee_embed(name: str, claim_id: str) -> str:
    return f"https://odysee.com/$/embed/{quote(name, safe='')}/{claim_id}"


class OdyseeSite(Site):
    source_id = "odysee"
    name = "Odysee"
    description = "Video platform - public search + LBRY API (plays in its own web player if needed)"
    hosts = ("odysee.com", "www.odysee.com")
    topic_based = True

    def _resolve_claims(self, lbry_urls: List[str]) -> str:
        body = {"jsonrpc": "2.0", "method": "resolve", "id": 1, "params": {"urls": lbry_urls}}
        return fetch_text(ODYSEE_API, json_body=body)

    def _find(self, query: str, page: int, limit: int) -> List[Entry]:
        hits = json.loads(fetch_text(
            f"https://lighthouse.odysee.tv/search?s={quote_plus(query)}&size={limit}&from={(page - 1) * limit}"
            "&claimType=file&mediaType=video&nsfw=false&free_only=true"))
        pairs = [(h.get("claimId", ""), h.get("name", "")) for h in hits if isinstance(h, dict)]
        pairs = [(cid, name) for cid, name in pairs if CLAIM_ID.match(cid) and name]
        if not pairs:
            return []
        return parse_odysee_resolve(self._resolve_claims([f"lbry://{name}#{cid}" for cid, name in pairs]))

    def search(self, query, page=1, limit=PER_PAGE):
        return self._find(query, page, limit)

    def latest(self, page=1, limit=PER_PAGE):
        return self._find(default_topic(page), 1, limit)

    def _stream_from_claim(self, claim: Optional[dict]) -> StreamInfo:
        claim = claim or {}
        claim_id, name = claim.get("claim_id") or "", claim.get("name") or ""
        if not CLAIM_ID.match(claim_id) or not name:
            raise SiteError("Could not find this Odysee video.")
        sd_hash = (((claim.get("value") or {}).get("source")) or {}).get("sd_hash") or ""
        urls = [odysee_stream_url(name, claim_id, sd_hash)] if len(sd_hash) >= 6 else []
        return StreamInfo(urls=urls, embed_url=odysee_embed(name, claim_id))

    def resolve(self, video_id):
        claim_id, _, name = video_id.partition(":")
        if not CLAIM_ID.match(claim_id) or not name:
            raise SiteError("Invalid Odysee video.")
        key = f"lbry://{name}#{claim_id}"
        result = (json.loads(self._resolve_claims([key])).get("result")) or {}
        return self._stream_from_claim(result.get(key))

    def resolve_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/(?:@[^/]+/)?([^/:]+):([0-9a-f]{1,40})/?$", p.path)
        if p.netloc not in self.hosts or not m:
            raise SiteError("That is not an Odysee video address.")
        key = f"lbry://{unquote(m.group(1))}#{m.group(2)}"
        result = (json.loads(self._resolve_claims([key])).get("result")) or {}
        return self._stream_from_claim(result.get(key))


# ---------------------------------------------------------------------------------------------
# Dailymotion - public API for listing; videos play in Dailymotion's web player
# ---------------------------------------------------------------------------------------------

DAILYMOTION_ID = re.compile(r"^[a-z0-9]{5,12}$")


def parse_dailymotion(text: str) -> List[Entry]:
    out = []
    for v in json.loads(text).get("list") or []:
        vid = (v or {}).get("id") or ""
        if not DAILYMOTION_ID.match(vid):
            continue
        created = v.get("created_time")
        published = datetime.fromtimestamp(int(created), timezone.utc).date().isoformat() if created else None
        out.append(_entry(
            "dailymotion", "Dailymotion", vid, v.get("title") or "", v.get("owner.screenname") or "",
            v.get("thumbnail_360_url"), int(v.get("duration") or 0),
            v.get("url") or f"https://www.dailymotion.com/video/{vid}", published=published,
        ))
    return out


class DailymotionSite(Site):
    source_id = "dailymotion"
    name = "Dailymotion"
    description = "Video platform - official public API; plays in Dailymotion's web player"
    hosts = ("www.dailymotion.com", "dailymotion.com")
    fields = "id,title,owner.screenname,thumbnail_360_url,duration,url,created_time"

    def _call(self, extra: str, page: int, limit: int) -> List[Entry]:
        return parse_dailymotion(fetch_text(
            f"https://api.dailymotion.com/videos?fields={quote(self.fields, safe='')}&limit={limit}&page={page}&family_filter=true{extra}"))

    def search(self, query, page=1, limit=PER_PAGE):
        return self._call(f"&sort=relevance&search={quote_plus(query)}", page, limit)

    def latest(self, page=1, limit=PER_PAGE):
        return self._call("&sort=recent", page, limit)

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/video/([a-z0-9]{5,12})", p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not DAILYMOTION_ID.match(video_id):
            raise SiteError("Invalid Dailymotion video.")
        return StreamInfo(urls=[], embed_url=f"https://www.dailymotion.com/embed/video/{video_id}?autoplay=1")


# ---------------------------------------------------------------------------------------------
# Vimeo - ids read from a Vimeo page, details from Vimeo's public oEmbed; plays in Vimeo's web player
# ---------------------------------------------------------------------------------------------

VIMEO_HREF = re.compile(r"^(?:https://vimeo\.com)?(?:/channels/[A-Za-z0-9_-]+)?/(\d{6,12})/?$")


def parse_vimeo_ids(html: str) -> List[str]:
    ids = []
    for a in _soup(html).select("a[href]"):
        m = VIMEO_HREF.match(a.get("href", "").split("?", 1)[0].split("#", 1)[0])
        if m:
            ids.append(m.group(1))
    return _distinct(ids)


def parse_vimeo_oembed(text: str, video_id: str) -> Optional[Entry]:
    o = json.loads(text)
    title = o.get("title") or ""
    if not title.strip():
        return None
    return _entry("vimeo", "Vimeo", video_id, title, o.get("author_name") or "", o.get("thumbnail_url"),
                  int(o.get("duration") or 0), f"https://vimeo.com/{video_id}")


class VimeoSite(Site):
    source_id = "vimeo"
    name = "Vimeo"
    description = "Video platform (web page reading + public oEmbed); plays in Vimeo's web player"
    hosts = ("vimeo.com", "www.vimeo.com", "player.vimeo.com")

    def _describe(self, ids: List[str], limit: int) -> List[Entry]:
        out = []
        for vid in ids[:limit]:
            try:
                entry = parse_vimeo_oembed(
                    fetch_text(f"https://vimeo.com/api/oembed.json?url={quote_plus(f'https://vimeo.com/{vid}')}"), vid)
            except Exception:
                entry = None  # private video, embedding switched off, odd answer, or Vimeo said no
            if entry:
                out.append(entry)
        return out

    def search(self, query, page=1, limit=PER_PAGE):
        url = "https://vimeo.com/search" + (f"/page:{page}" if page > 1 else "") + f"?q={quote_plus(query)}"
        return self._describe(parse_vimeo_ids(fetch_text(url, scrape=True)), limit)

    def latest(self, page=1, limit=PER_PAGE):
        return self._describe(parse_vimeo_ids(fetch_text(f"https://vimeo.com/channels/staffpicks/videos?page={page}", scrape=True)), limit)

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/(?:channels/[^/]+/|video/)?(\d{6,12})/?$", p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not video_id.isdigit():
            raise SiteError("Invalid Vimeo video.")
        return StreamInfo(urls=[], embed_url=f"https://player.vimeo.com/video/{video_id}?autoplay=1")


# ---------------------------------------------------------------------------------------------
# The list of sites
# ---------------------------------------------------------------------------------------------

# (source id, name, host). The first keeps the id "peertube" that the app already knows.
PEERTUBE_INSTANCES = [
    ("peertube", "Diode Zone", "diode.zone"),
    ("framatube", "Framatube", "framatube.org"),
    ("tilvids", "TILvids", "tilvids.com"),
    ("peertubetv", "PeerTube.tv", "peertube.tv"),
    ("conftube", "ConfTube", "conftube.com"),
]

ALL_SITES: List[Site] = [
    PexelsSite(), PixabaySite(), MixkitSite(), RumbleSite(), OdyseeSite(),
    *[PeerTubeSite(host, sid, name) for sid, name, host in PEERTUBE_INSTANCES],
    WikimediaSite(), DailymotionSite(), VimeoSite(),
]

# The newer sites live in sites_more.py (imported here, after everything they build on is defined).
from .sites_more import MORE_SITES  # noqa: E402

ALL_SITES.extend(MORE_SITES)

# Step 16: 30 news / science / education sites (sites_news.py). Added at the end, so nothing above changes.
from .sites_news import NEWS_SITES  # noqa: E402

ALL_SITES.extend(NEWS_SITES)
SITES_BY_ID = {s.source_id: s for s in ALL_SITES}


def site_for_host(host: str) -> Optional[Site]:
    host = host.lower()
    for site in ALL_SITES:
        if host in site.hosts:
            return site
    return None
