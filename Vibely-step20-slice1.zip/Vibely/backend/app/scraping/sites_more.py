"""More sites (step 14). Same rules as ``sites.py``: public APIs where they exist, page reading otherwise, robots.txt
honoured for pages, one extractor per site, pure parsing functions that can be tested with saved snippets.

This module is imported by ``sites.py`` (never import it directly: ``from app.scraping.sites import ...``).

Two kinds of site live here, and **none of them needs an API key**:

* **Always on** - BitChute, D.Tube, 9GAG, FailArmy, eBaum's World, Videvo, Giphy, Tenor, Imgur, Coverr. Giphy, Tenor,
  Imgur, Coverr and Videvo are read from their ordinary web pages (robots.txt decides), the others from the public
  endpoint their own website uses.
* **Off by default** - AFV, The Dodo, Cheezburger. Their pages are mostly YouTube embeds, articles or memes, so most
  items would not play. Switch one on with ``ENABLE_SITES=afv,thedodo`` if you want to try it.

Reddit is **not** here: its robots.txt forbids every automatic reader, and Vibely does not go around robots.txt.

Adult content is filtered out where a site mixes it in (a word filter on titles, plus each site's own "safe" setting).
"""
from __future__ import annotations

import html as htmllib
import json
import os
import re
import time
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote_plus, urljoin, urlparse

from .models import Entry, StreamInfo
from .polite import fetch_text
from .sites import (
    PER_PAGE, Site, SiteError, _distinct, _entry, _first, _linked_thumbnail, _soup, _unescape_json_urls,
    default_topic, seconds_from_text, slugify, title_from_slug,
)

# ---------------------------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------------------------

ADULT_WORDS = re.compile(
    r"\b(nsfw|porn\w*|nude\w*|naked|sex\w*|xxx|18\+|horny|boob\w*|nipple\w*|erotic\w*|onlyfans|fetish|hentai)\b", re.I)


def looks_adult(*texts: Optional[str]) -> bool:
    """Cheap safety net for sites that mix adult posts into their feeds."""
    return any(t and ADULT_WORDS.search(t) for t in texts)


def env_enabled_sites() -> List[str]:
    """``ENABLE_SITES=afv,thedodo`` switches on sites that are off by default."""
    return [s.strip().lower() for s in os.environ.get("ENABLE_SITES", "").split(",") if s.strip()]


PAGE_ID = re.compile(r"^[A-Za-z0-9_\-./]{1,200}$")
DURATION_TEXT = re.compile(r"^\d{1,2}(:\d{2}){1,2}$")
MEDIA_URL = re.compile(r"""https://[^"'\s<>\\]+?\.(?:mp4|m3u8|webm)(?:\?[^"'\s<>\\]*)?""", re.I)
YOUTUBE_HOST = re.compile(r"(?:youtube\.com|youtube-nocookie\.com|youtu\.be)", re.I)
# Web players that Vibely may show inside the app (a page on one of these hosts, containing one of these paths).
EMBED_PLAYERS = (
    ("player.vimeo.com", "/video/"), ("www.dailymotion.com", "/embed/"), ("rumble.com", "/embed/"),
    ("odysee.com", "/$/embed/"), ("www.bitchute.com", "/embed/"),
)


def _walk(node):
    """Every dict inside nested JSON (used for JSON-LD)."""
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk(value)
    elif isinstance(node, list):
        for value in node:
            yield from _walk(value)


def _media_rank(url: str) -> int:
    lower = url.lower().split("?", 1)[0]
    return 2 if lower.endswith(".m3u8") else 1 if lower.endswith(".webm") else 0


def sniff_page(page_html: str, base_url: str) -> Tuple[List[str], Optional[str], bool]:
    """What can be played on an ordinary video page?

    Returns ``(direct file links best first, web-player address or None, page uses YouTube)``. Looks at the
    ``og:video`` tags, ``<video>`` / ``<source>`` tags, JSON-LD ``VideoObject`` and any ``.mp4/.m3u8/.webm`` link in
    the page, then at ``<iframe>`` players of a few sites Vibely can show inside the app.
    """
    text = _unescape_json_urls(page_html)
    soup = _soup(page_html)
    candidates: List[Optional[str]] = []
    for selector in ("meta[property='og:video:secure_url']", "meta[property='og:video']",
                     "meta[name='twitter:player:stream']"):
        candidates += [m.get("content") for m in soup.select(selector)]
    candidates += [v.get("src") for v in soup.select("video[src], video source[src]")]
    for script in soup.select("script[type='application/ld+json']"):
        try:
            data = json.loads(script.string or "")
        except ValueError:
            continue
        for node in _walk(data):
            if "VideoObject" in str(node.get("@type", "")):
                candidates.append(node.get("contentUrl"))
    candidates += [m.group(0) for m in MEDIA_URL.finditer(text)]

    youtube = bool(re.search(r"youtube(?:-nocookie)?\.com/embed/|youtu\.be/", text))
    urls: List[str] = []
    for candidate in candidates:
        if not candidate:
            continue
        absolute = urljoin(base_url, htmllib.unescape(candidate))
        if YOUTUBE_HOST.search(urlparse(absolute).netloc):
            youtube = True
        elif absolute.startswith("https://") and re.search(r"\.(?:mp4|m3u8|webm)(?:\?|$)", absolute, re.I):
            urls.append(absolute)
    urls = sorted(_distinct(urls), key=_media_rank)

    embed: Optional[str] = None
    for frame in soup.select("iframe[src], iframe[data-src]"):
        src = urljoin(base_url, frame.get("src") or frame.get("data-src") or "")
        parsed = urlparse(src)
        if YOUTUBE_HOST.search(parsed.netloc):
            youtube = True
        elif embed is None and any(parsed.netloc == h and part in src for h, part in EMBED_PLAYERS):
            embed = src
    return urls, embed, youtube


def parse_cards(page_html: str, base: str, link_re, source_id: str, source_name: str, suffix: str = "",
                exclude: Iterable[str] = ()) -> List[Entry]:
    """Video cards on a listing page: every link whose *path* matches ``link_re`` (group 1 = the page id).

    A card often has several links to the same video (picture, title, comments), so title, picture and duration are
    collected from all of them.
    """
    base_host = urlparse(base).netloc.replace("www.", "")
    skip = set(exclude)
    cards: Dict[str, dict] = {}
    for a in _soup(page_html).select("a[href]"):
        parsed = urlparse(urljoin(base, a.get("href", "")))
        if parsed.netloc.replace("www.", "") != base_host:
            continue
        m = link_re.match(parsed.path)
        if not m:
            continue
        vid = m.group(1).strip("/")
        if not PAGE_ID.match(vid) or ".." in vid or vid in skip:
            continue
        card = cards.setdefault(vid, {"titles": [], "thumb": None, "duration": None})
        heading = a.select_one("h1, h2, h3, h4")
        for raw in (a.get("title"), heading.get_text(" ", strip=True) if heading else None, a.get_text(" ", strip=True)):
            text = (raw or "").strip()
            if text and DURATION_TEXT.match(text):
                card["duration"] = card["duration"] or text
            elif text:
                card["titles"].append(text)
        img = a.select_one("img")
        if img and img.get("alt"):
            card["titles"].append(img["alt"].strip())
        card["thumb"] = card["thumb"] or _linked_thumbnail(a, base)
    out = []
    for vid, card in cards.items():
        title = max(card["titles"], key=len) if card["titles"] else title_from_slug(vid)
        if looks_adult(title):
            continue
        out.append(_entry(source_id, source_name, vid, title[:200], source_name, card["thumb"], None,
                          f"{base}/{vid}{suffix}", duration_text=card["duration"]))
    return out


# ---------------------------------------------------------------------------------------------
# Generic "read the pages" site (FailArmy, eBaum's World, Videvo, D.Tube, AFV, The Dodo, Cheezburger)
# ---------------------------------------------------------------------------------------------

class GenericSite(Site):
    """A site read from its HTML. Subclasses only say where the lists are and what a video link looks like."""

    list_url = ""          # {page}
    search_url = ""        # {q} {slug} {page}; empty = the site has no usable search page
    link_re = re.compile(r"^$")
    suffix = ""            # "/" if the site's page addresses end with a slash
    exclude: Tuple[str, ...] = ()
    default_on = True
    off_reason = ""

    @property
    def base(self) -> str:
        return f"https://{self.hosts[0]}"

    def enabled(self) -> bool:
        return self.default_on or self.source_id in env_enabled_sites()

    def disabled_reason(self) -> Optional[str]:
        if self.enabled():
            return None
        return f"Off by default: {self.off_reason} Add '{self.source_id}' to ENABLE_SITES to try it."

    def _cards(self, page_html: str) -> List[Entry]:
        return parse_cards(page_html, self.base, self.link_re, self.source_id, self.name, self.suffix, self.exclude)

    def latest(self, page=1, limit=PER_PAGE):
        if not self.paged and page > 1:
            return []
        return self._cards(fetch_text(self.list_url.format(page=page), scrape=True))[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        if not self.search_url or not slugify(query):
            return []
        url = self.search_url.format(q=quote_plus(query), slug=slugify(query), page=page)
        return self._cards(fetch_text(url, scrape=True))[:limit]

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = self.link_re.match(p.path)
        return m.group(1).strip("/") if p.netloc in self.hosts and m else None

    def page_url(self, video_id: str) -> str:
        return f"{self.base}/{video_id}{self.suffix}"

    def resolve(self, video_id):
        if not PAGE_ID.match(video_id) or ".." in video_id:
            raise SiteError(f"Invalid {self.name} video.")
        page_url = self.page_url(video_id)
        urls, embed, youtube = sniff_page(fetch_text(page_url, scrape=True), page_url)
        if urls or embed:
            return StreamInfo(urls=urls, embed_url=embed)
        if youtube:
            raise SiteError(f"This {self.name} video is hosted on YouTube, which Vibely does not support.")
        raise SiteError(f"Could not find a video on this {self.name} page. Tap Retry or try another video.")


# ----- D.Tube: the home page is plain HTML (cards link to /watch/<id>) -----

class DTubeSite(GenericSite):
    source_id = "dtube"
    name = "D.Tube"
    description = "Decentralised video site (web page reading; plays in its own page if there is no file)"
    hosts = ("d.tube", "www.d.tube")
    list_url = "https://d.tube/latest"
    paged = False
    link_re = re.compile(r"^/(watch/[A-Za-z0-9]{8,40})/?$")

    def resolve(self, video_id):
        try:
            return super().resolve(video_id)
        except SiteError:
            if not PAGE_ID.match(video_id):
                raise
            return StreamInfo(urls=[], embed_url=self.page_url(video_id))   # D.Tube's own page as the web player


# ----- FailArmy: a WordPress site, so its public WordPress API lists the newest posts -----

def parse_wp_posts(text: str, source_id: str, source_name: str, host: str) -> List[Entry]:
    out = []
    for post in json.loads(text):
        if not isinstance(post, dict):
            continue
        parsed = urlparse(post.get("link") or "")
        vid = parsed.path.strip("/")
        if parsed.netloc.replace("www.", "") != host.replace("www.", "") or not PAGE_ID.match(vid) or ".." in vid:
            continue
        title = _soup((post.get("title") or {}).get("rendered") or "").get_text(" ", strip=True)
        og = ((post.get("yoast_head_json") or {}).get("og_image") or [{}])[0] or {}
        if not title or looks_adult(title):
            continue
        out.append(_entry(source_id, source_name, vid, title[:200], source_name,
                          _first(og.get("url"), post.get("jetpack_featured_media_url")), None,
                          f"https://{host}/{vid}/", published=(post.get("date") or "")[:10]))
    return out


class FailArmySite(GenericSite):
    source_id = "failarmy"
    name = "FailArmy"
    description = "Fail compilations and clips (WordPress API + page reading)"
    hosts = ("www.failarmy.com", "failarmy.com")
    list_url = "https://www.failarmy.com/"
    suffix = "/"
    link_re = re.compile(r"^/([a-z0-9][a-z0-9-]{8,}/?)$")
    exclude = ("about", "contact", "privacy-policy", "terms-of-use", "submit-video", "category", "tag", "author")
    _fields = "link,title,date,yoast_head_json,jetpack_featured_media_url"

    def _wp(self, page: int, limit: int, search: str = "") -> List[Entry]:
        url = (f"https://www.failarmy.com/wp-json/wp/v2/posts?per_page={limit}&page={page}&_fields={self._fields}"
               + (f"&search={quote_plus(search)}" if search else ""))
        return parse_wp_posts(fetch_text(url, scrape=True), self.source_id, self.name, "www.failarmy.com")

    def latest(self, page=1, limit=PER_PAGE):
        try:
            return self._wp(page, limit)
        except Exception:
            if page > 1:
                raise
            return super().latest(page, limit)       # the WordPress API is switched off: read the home page

    def search(self, query, page=1, limit=PER_PAGE):
        return self._wp(page, limit, query) if query.strip() else []


# ----- eBaum's World: the video list is on the "videos" page; the site also has many adult posts (filtered) -----

class EbaumsworldSite(GenericSite):
    source_id = "ebaumsworld"
    name = "eBaum's World"
    description = "Funny videos (web page reading; adult posts are filtered out)"
    hosts = ("www.ebaumsworld.com", "ebaumsworld.com")
    list_url = "https://www.ebaumsworld.com/videos/"
    paged = False
    suffix = "/"
    link_re = re.compile(r"^/(videos/[a-z0-9-]+/\d+)/?$")


# ----- Videvo: free stock footage; no "newest" page that is easy to read, so a rotating topic is used -----

class VidevoSite(GenericSite):
    source_id = "videvo"
    name = "Videvo"
    description = "Free stock video clips (web page reading)"
    hosts = ("www.videvo.net", "videvo.net")
    topic_based = True
    search_url = "https://www.videvo.net/search/{slug}/"
    suffix = "/"
    link_re = re.compile(r"^/(video/[a-z0-9-]+/\d+)/?$")

    def latest(self, page=1, limit=PER_PAGE):
        return self.search(default_topic(page), 1, limit)


# ----- Off by default: most of what these pages show cannot be played inside Vibely -----

class AfvSite(GenericSite):
    source_id = "afv"
    name = "AFV"
    description = "America's Funniest Home Videos (web page reading)"
    hosts = ("www.afv.com", "afv.com")
    list_url = "https://www.afv.com/funny-videos"
    paged = False
    link_re = re.compile(r"^/([a-z0-9][a-z0-9-]{8,})/?$")
    exclude = ("assignment-america", "where-to-watch", "winners-circle", "funny-videos", "about-the-contest",
               "contest-rules", "grand-prize", "privacy")
    default_on = False
    off_reason = "its videos are mostly YouTube clips, which Vibely does not play."


class DodoSite(GenericSite):
    source_id = "thedodo"
    name = "The Dodo"
    description = "Animal rescue videos (web page reading)"
    hosts = ("www.thedodo.com", "thedodo.com")
    list_url = "https://www.thedodo.com/watch"
    paged = False
    link_re = re.compile(r"^/((?:watch|video)/[a-z0-9-]+)/?$")
    default_on = False
    off_reason = "its pages block automatic readers and many videos are embedded from other services."


class CheezburgerSite(GenericSite):
    source_id = "cheezburger"
    name = "Cheezburger"
    description = "Memes and funny posts (web page reading)"
    hosts = ("cheezburger.com", "www.cheezburger.com")
    list_url = "https://cheezburger.com/page/{page}"
    link_re = re.compile(r"^/(\d{6,}/[a-z0-9-]+)/?$")
    default_on = False
    off_reason = "it is mostly pictures and articles, only a few posts contain a video."


# ---------------------------------------------------------------------------------------------
# 9GAG - its public JSON feed (also web-page reading, so robots.txt decides)
# ---------------------------------------------------------------------------------------------

NINEGAG_ID = re.compile(r"^[A-Za-z0-9]{5,12}$")


def parse_9gag(text: str) -> List[Entry]:
    """Only animated posts (they have an mp4); posts flagged NSFW are skipped."""
    out = []
    posts = ((json.loads(text).get("data") or {}).get("posts")) or []
    for p in posts:
        if not isinstance(p, dict) or p.get("type") != "Animated" or p.get("nsfw"):
            continue
        vid, title = p.get("id") or "", p.get("title") or ""
        images = p.get("images") or {}
        video = images.get("image460sv") or {}
        if not NINEGAG_ID.match(vid) or looks_adult(title) or not str(video.get("url", "")).startswith("https://"):
            continue
        created = p.get("creationTs")
        published = time.strftime("%Y-%m-%d", time.gmtime(int(created))) if created else None
        out.append(_entry("9gag", "9GAG", vid, title, "9GAG", (images.get("image460") or {}).get("url"),
                          int(video.get("duration") or 0), f"https://9gag.com/gag/{vid}", published=published))
    return out


class NineGagSite(Site):
    source_id = "9gag"
    name = "9GAG"
    description = "Funny clips (public feed; it often blocks servers - the app then skips it)"
    hosts = ("9gag.com", "www.9gag.com")
    paged = False

    def latest(self, page=1, limit=PER_PAGE):
        if page > 1:
            return []
        return parse_9gag(fetch_text("https://9gag.com/v1/group-posts/group/default/type/fresh", scrape=True))[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        return []       # 9GAG has no public search; the saved catalogue is searched instead

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/gag/([A-Za-z0-9]{5,12})/?$", p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not NINEGAG_ID.match(video_id):
            raise SiteError("Invalid 9GAG video.")
        page_url = f"https://9gag.com/gag/{video_id}"
        try:
            urls, embed, _ = sniff_page(fetch_text(page_url, scrape=True), page_url)
        except Exception:
            urls, embed = [], None
        if not urls:
            urls = [f"https://img-9gag-fun.9cache.com/photo/{video_id}_460sv.mp4"]   # 9GAG's usual file address
        return StreamInfo(urls=urls, embed_url=embed)


# ---------------------------------------------------------------------------------------------
# BitChute - its search API (the same one the open-source SearXNG engine uses); yt-dlp gives the file
# ---------------------------------------------------------------------------------------------

BITCHUTE_ID = re.compile(r"^[A-Za-z0-9_-]{6,20}$")


def _bitchute_seconds(value) -> Optional[int]:
    if isinstance(value, (int, float)):
        return int(value)
    return seconds_from_text(value) if isinstance(value, str) else None


def parse_bitchute(text: str) -> List[Entry]:
    out = []
    for v in json.loads(text).get("videos") or []:
        if not isinstance(v, dict):
            continue
        vid, title = v.get("video_id") or "", v.get("video_name") or ""
        if not BITCHUTE_ID.match(vid) or not title or looks_adult(title):
            continue
        channel = v.get("channel") or {}
        out.append(_entry(
            "bitchute", "BitChute", vid, title, channel.get("channel_name") or "", v.get("thumbnail_url"),
            _bitchute_seconds(v.get("duration")), f"https://www.bitchute.com/video/{vid}/",
            published=(v.get("date_published") or "")[:10] or None,
        ))
    return out


class BitChuteSite(Site):
    source_id = "bitchute"
    name = "BitChute"
    description = "Video platform (search API; direct file through yt-dlp, otherwise its web player)"
    hosts = ("www.bitchute.com", "bitchute.com")
    topic_based = True
    prefer_ytdlp = True
    api = "https://api.bitchute.com/api/beta/search/videos"

    def _find(self, query: str, page: int, limit: int) -> List[Entry]:
        body = {"offset": (page - 1) * limit, "limit": limit, "query": query,
                "sensitivity_id": "normal", "sort": "new"}
        return parse_bitchute(fetch_text(self.api, json_body=body))

    def search(self, query, page=1, limit=PER_PAGE):
        return self._find(query, page, limit)

    def latest(self, page=1, limit=PER_PAGE):
        return self._find(default_topic(page), 1, limit)

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/(?:video|embed)/([A-Za-z0-9_-]{6,20})/?$", p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not BITCHUTE_ID.match(video_id):
            raise SiteError("Invalid BitChute video.")
        return StreamInfo(urls=[], embed_url=f"https://www.bitchute.com/embed/{video_id}/")


# ---------------------------------------------------------------------------------------------
# Giphy, Tenor, Imgur, Coverr - ordinary web pages, NO API key (step 15)
#
# Every one of them is read like a visitor's browser reads it: robots.txt is checked first (``scrape=True``), and if a
# site says no, blocks the server or changes its layout, that site is skipped and ``/api/sources`` shows why.
# ---------------------------------------------------------------------------------------------

# ----- Giphy: pages link to /gifs/<words>-<id>; the video of a clip always sits at media.giphy.com/media/<id>/giphy.mp4 -----

GIPHY_ID = re.compile(r"^[A-Za-z0-9]{6,24}$")
GIPHY_PATH = re.compile(r"^/(?:gifs|clips)/(?:(?P<slug>[^/]+?)-)?(?P<id>[A-Za-z0-9]{6,24})/?$")
GIPHY_MEDIA_PATH = re.compile(r"^/media/(?:v1\.[A-Za-z0-9_=\-]+/)?(?P<id>[A-Za-z0-9]{6,24})/")
GIPHY_MEDIA = re.compile(r"giphy\.com/media/(?:v1\.[A-Za-z0-9_=\-]+/)?([A-Za-z0-9]{6,24})/")


def _giphy_id_ok(media_id: str) -> bool:
    """Giphy ids are mixed-case / contain digits; a plain lowercase word in a link is a category, not a clip."""
    return bool(GIPHY_ID.match(media_id)) and bool(re.search(r"[A-Z0-9]", media_id))


def giphy_mp4_urls(media_id: str) -> List[str]:
    return [f"https://media.giphy.com/media/{media_id}/giphy.mp4", f"https://i.giphy.com/media/{media_id}/giphy.mp4"]


def parse_giphy_page(page_html: str) -> List[Entry]:
    """Clips on a Giphy list / search page: from the links, plus any clip whose picture address shows up in the page."""
    cards: Dict[str, dict] = {}
    for a in _soup(page_html).select("a[href]"):
        parsed = urlparse(urljoin("https://giphy.com/", a.get("href", "")))
        if parsed.netloc.replace("www.", "") != "giphy.com":
            continue
        m = GIPHY_PATH.match(parsed.path)
        if not m or not _giphy_id_ok(m.group("id")):
            continue
        card = cards.setdefault(m.group("id"), {"slug": None, "alt": None})
        card["slug"] = card["slug"] or m.group("slug")
        img = a.select_one("img")
        if img and img.get("alt"):
            card["alt"] = card["alt"] or img["alt"].strip()
    for media_id in GIPHY_MEDIA.findall(_unescape_json_urls(page_html)):
        if _giphy_id_ok(media_id):
            cards.setdefault(media_id, {"slug": None, "alt": None})
    out = []
    for gid, card in cards.items():
        title = (title_from_slug(card["slug"]) if card["slug"] else "") or card["alt"] or "Giphy clip"
        if looks_adult(title):
            continue
        out.append(_entry("giphy", "Giphy", gid, title[:200], "Giphy", f"https://media.giphy.com/media/{gid}/200_s.gif",
                          None, f"https://giphy.com/gifs/{gid}"))
    return out


class GiphySite(Site):
    source_id = "giphy"
    name = "Giphy"
    description = "Short looping clips (web page reading, no key; clips have no sound)"
    hosts = ("giphy.com", "www.giphy.com", "media.giphy.com", "i.giphy.com")
    paged = False
    scrape_every = 2

    def latest(self, page=1, limit=PER_PAGE):
        if page > 1:
            return []
        return parse_giphy_page(fetch_text("https://giphy.com/", scrape=True))[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        slug = slugify(query)
        if not slug or page > 1:
            return []
        return parse_giphy_page(fetch_text(f"https://giphy.com/search/{slug}", scrape=True))[:limit]

    def video_id_from_url(self, url):
        p = urlparse(url)
        if p.netloc not in self.hosts:
            return None
        m = GIPHY_PATH.match(p.path) or GIPHY_MEDIA_PATH.match(p.path)
        return m.group("id") if m and _giphy_id_ok(m.group("id")) else None

    def resolve(self, video_id):
        if not _giphy_id_ok(video_id):
            raise SiteError("Invalid Giphy clip.")
        return StreamInfo(urls=giphy_mp4_urls(video_id))


# ----- Tenor: pages link to /view/<words>-gif-<number>; the video file is named on the clip's own page -----

TENOR_PATH = re.compile(r"^(?:/[a-z]{2}(?:-[A-Za-z]{2})?)?/view/(?P<vid>(?:[A-Za-z0-9_\-]+?-)?(?P<id>\d{5,25}))/?$")


def parse_tenor_page(page_html: str) -> List[Entry]:
    cards: Dict[str, dict] = {}
    for a in _soup(page_html).select("a[href]"):
        parsed = urlparse(urljoin("https://tenor.com/", a.get("href", "")))
        if parsed.netloc.replace("www.", "") != "tenor.com":
            continue
        m = TENOR_PATH.match(parsed.path)
        if not m:
            continue
        card = cards.setdefault(m.group("vid"), {"thumb": None, "alt": None})
        card["thumb"] = card["thumb"] or _linked_thumbnail(a, "https://tenor.com/")
        img = a.select_one("img")
        if img and img.get("alt"):
            card["alt"] = card["alt"] or img["alt"].strip()
    out = []
    for vid, card in cards.items():
        title = re.sub(r"\s+gifv?$", "", title_from_slug(vid), flags=re.I).strip() or card["alt"] or "Tenor clip"
        if looks_adult(title):
            continue
        out.append(_entry("tenor", "Tenor", vid, title[:200], "Tenor", card["thumb"], None, f"https://tenor.com/view/{vid}"))
    return out


class TenorSite(Site):
    source_id = "tenor"
    name = "Tenor"
    description = "Short looping clips (web page reading, no key; clips have no sound)"
    hosts = ("tenor.com", "www.tenor.com")
    paged = False
    scrape_every = 2

    def latest(self, page=1, limit=PER_PAGE):
        if page > 1:
            return []
        return parse_tenor_page(fetch_text("https://tenor.com/", scrape=True))[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        slug = slugify(query)
        if not slug or page > 1:
            return []
        return parse_tenor_page(fetch_text(f"https://tenor.com/search/{slug}-gifs", scrape=True))[:limit]

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = TENOR_PATH.match(p.path)
        return m.group("vid") if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not PAGE_ID.match(video_id) or ".." in video_id:
            raise SiteError("Invalid Tenor clip.")
        page_url = f"https://tenor.com/view/{video_id}"
        urls, embed, _ = sniff_page(fetch_text(page_url, scrape=True), page_url)
        urls = [u for u in urls if urlparse(u).netloc.endswith("tenor.com")] or urls
        if not urls and not embed:
            raise SiteError("This Tenor clip has no video file.")
        return StreamInfo(urls=urls, embed_url=embed)


# ----- Imgur: the pages are mostly script-built, so only clips that can be recognised are taken (best effort) -----

IMGUR_ID = re.compile(r"^[A-Za-z0-9]{5,10}$")
IMGUR_PATH = re.compile(r"^/gallery/(?:(?P<slug>[^/]+?)-)?(?P<id>[A-Za-z0-9]{5,10})/?$")
IMGUR_FILE = re.compile(r"i\.imgur\.com/([A-Za-z0-9]{5,10})\.(?:mp4|gifv)")


def parse_imgur_page(page_html: str) -> List[Entry]:
    """Posts that are certainly videos: a link that holds a ``<video>``, or a picture address ending in .mp4 / .gifv."""
    cards: Dict[str, dict] = {}
    soup = _soup(page_html)
    for a in soup.select("a[href]"):
        parsed = urlparse(urljoin("https://imgur.com/", a.get("href", "")))
        if parsed.netloc.replace("www.", "") != "imgur.com":
            continue
        m = IMGUR_PATH.match(parsed.path)
        if not m or not a.select_one("video, source"):
            continue
        img = a.select_one("img")
        title = (a.get("title") or (img.get("alt") if img else "") or "").strip()
        cards.setdefault(m.group("id"), {"title": title or (title_from_slug(m.group("slug")) if m.group("slug") else "")})
    for image_id in IMGUR_FILE.findall(_unescape_json_urls(page_html)):
        cards.setdefault(image_id, {"title": ""})
    out = []
    for iid, card in cards.items():
        title = card["title"] or "Imgur video"
        if looks_adult(title):
            continue
        out.append(_entry("imgur", "Imgur", iid, title[:200], "Imgur", f"https://i.imgur.com/{iid}m.jpg", None,
                          f"https://imgur.com/gallery/{iid}"))
    return out


class ImgurSite(Site):
    source_id = "imgur"
    name = "Imgur"
    description = "Funny and viral clips (web page reading, best effort; Imgur often blocks servers)"
    hosts = ("imgur.com", "www.imgur.com", "i.imgur.com")
    paged = False
    scrape_every = 2

    def latest(self, page=1, limit=PER_PAGE):
        if page > 1:
            return []
        return parse_imgur_page(fetch_text("https://imgur.com/t/funny", scrape=True))[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        if not query.strip() or page > 1:
            return []
        return parse_imgur_page(fetch_text(f"https://imgur.com/search?q={quote_plus(query)}", scrape=True))[:limit]

    def video_id_from_url(self, url):
        p = urlparse(url)
        if p.netloc not in self.hosts:
            return None
        m = IMGUR_PATH.match(p.path) or re.match(r"^/(?P<id>[A-Za-z0-9]{5,10})(?:\.(?:mp4|gifv))?/?$", p.path)
        return m.group("id") if m else None

    def resolve(self, video_id):
        if not IMGUR_ID.match(video_id):
            raise SiteError("Invalid Imgur video.")
        page_url = f"https://imgur.com/gallery/{video_id}"
        try:
            urls, embed, _ = sniff_page(fetch_text(page_url, scrape=True), page_url)
        except Exception:
            urls, embed = [], None
        urls = [u for u in urls if urlparse(u).netloc.endswith("imgur.com")]
        return StreamInfo(urls=_distinct(urls + [f"https://i.imgur.com/{video_id}.mp4"]), embed_url=embed)


# ----- Coverr: free stock footage; the video page names its own .mp4 -----

class CoverrSite(GenericSite):
    source_id = "coverr"
    name = "Coverr"
    description = "Free stock video clips (web page reading, no key; clips have no sound)"
    hosts = ("coverr.co", "www.coverr.co")
    topic_based = True
    scrape_every = 2
    search_url = "https://coverr.co/s?q={q}"
    link_re = re.compile(r"^/(videos/[A-Za-z0-9_-]{4,80})/?$")

    def latest(self, page=1, limit=PER_PAGE):
        return self.search(default_topic(page), 1, limit)


MORE_SITES: List[Site] = [
    BitChuteSite(), DTubeSite(), NineGagSite(), FailArmySite(), EbaumsworldSite(), VidevoSite(),
    GiphySite(), TenorSite(), ImgurSite(), CoverrSite(),
    AfvSite(), DodoSite(), CheezburgerSite(),
]
