"""News, science and education video sources (step 16): 30 websites, none of them needs an API key.

Same rules as ``sites.py`` / ``sites_more.py``: robots.txt is honoured for every page, requests are spaced out, one
site failing never stops the others, and the parsing functions are pure (text in, entries out) so they can be tested
with saved snippets and repaired quickly when a website changes its layout.

This module is imported by ``sites.py`` (never import it directly: ``from app.scraping.sites import ...``).

How a news site is read (``NewsSite``), in this order, until enough videos are found:

1. the listing page you gave (e.g. ``https://www.dw.com/en/media-center/videos/s-100825``):
   * **JSON-LD** ``VideoObject`` blocks (many publishers describe their videos there: title, picture, duration, date);
   * **video links** whose address looks like that site's video pages (a small regular expression per site);
2. the site's **RSS / Atom feed** (a known feed address, or the one the listing page announces in its ``<head>``).
   A feed item is only kept when it carries a video (``media:content`` / enclosure) or links to a video page, so plain
   articles on mixed sites (BBC News, NPR, Live Science ...) are left out.

Playing: when someone taps a video, ``sniff_page`` looks for a direct ``.mp4`` / ``.m3u8`` (``og:video``, ``<video>``,
JSON-LD, links in the page) or a web player Vibely can show. If the page gives nothing, ``stream.py`` asks yt-dlp
(these sites are on its allowlist because they are registered here). Videos that only exist as a YouTube embed cannot
be played: YouTube is blocked on purpose and the app shows a clear message instead.

NASA is the exception: it has an official, free public API (images-api.nasa.gov) that gives direct ``.mp4`` files, so
that is used instead of page reading.
"""
from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote, quote_plus, urljoin, urlparse

from .models import Entry, StreamInfo
from .polite import fetch_text
from .sites import PER_PAGE, Site, SiteError, _distinct, _entry, _soup, seconds_from_text
from .sites_more import PAGE_ID, GenericSite, _walk, looks_adult

# A listing that gave at least this many videos is "good enough": the extra page / feed is not asked for.
ENOUGH = 6

ISO_DURATION = re.compile(r"^P(?:\d+D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?$", re.I)
ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}")


# ---------------------------------------------------------------------------------------------
# Small pure helpers
# ---------------------------------------------------------------------------------------------

def seconds_from_iso(value) -> Optional[int]:
    """'PT1M30S' -> 90, 'PT2H' -> 7200, 125 -> 125, '3:21' -> 201, anything else -> None."""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return int(value) if value > 0 else None
    text = str(value or "").strip()
    if not text:
        return None
    if text.isdigit():
        return int(text) or None
    m = ISO_DURATION.match(text)
    if m and any(m.groups()):
        h, mi, s = m.groups()
        total = int(h or 0) * 3600 + int(mi or 0) * 60 + int(float(s or 0))
        return total or None
    return seconds_from_text(text)


def _host(netloc: str) -> str:
    return netloc.lower().replace("www.", "", 1)


def _host_ok(url: str, hosts: Sequence[str]) -> bool:
    parsed = urlparse(url)
    return parsed.scheme == "https" and _host(parsed.netloc) in {_host(h) for h in hosts}


def _text(value) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, dict):
        return _text(value.get("name") or value.get("@value") or "")
    if isinstance(value, list) and value:
        return _text(value[0])
    return ""


def _image(value) -> Optional[str]:
    if isinstance(value, str):
        return value
    if isinstance(value, list) and value:
        return _image(value[0])
    if isinstance(value, dict):
        return _image(value.get("url") or value.get("contentUrl"))
    return None


def _date(value) -> Optional[str]:
    text = str(value or "").strip()
    return text[:10] if ISO_DATE.match(text) else None


def _page_id(path: str, link_re) -> Optional[str]:
    """The id of a video page: group 1 of the site's link pattern, or (for pages the pattern does not know) the path."""
    m = link_re.match(path)
    vid = (m.group(1) if m else path).strip("/")
    return vid if vid and PAGE_ID.match(vid) and ".." not in vid else None


def _dedupe(entries: Iterable[Entry]) -> List[Entry]:
    seen = set()
    out = []
    for e in entries:
        if e.video_id not in seen:
            seen.add(e.video_id)
            out.append(e)
    return out


# ---------------------------------------------------------------------------------------------
# JSON-LD VideoObject blocks on a listing page
# ---------------------------------------------------------------------------------------------

def parse_jsonld_videos(page_html: str, base: str, hosts: Sequence[str], source_id: str, source_name: str,
                        suffix: str = "") -> List[Entry]:
    out: List[Entry] = []
    link_none = re.compile(r"^$")
    for script in _soup(page_html).select("script[type='application/ld+json']"):
        try:
            data = json.loads(script.string or script.get_text() or "")
        except ValueError:
            continue
        for node in _walk(data):
            if "VideoObject" not in str(node.get("@type", "")):
                continue
            url = node.get("url") or node.get("@id")
            if not isinstance(url, str) or not _host_ok(url, hosts):
                continue
            vid = _page_id(urlparse(url).path, link_none)
            title = _text(node.get("name") or node.get("headline"))
            if not vid or not title or looks_adult(title):
                continue
            out.append(_entry(
                source_id, source_name, vid, title[:200], _text(node.get("publisher")) or source_name,
                _image(node.get("thumbnailUrl")), seconds_from_iso(node.get("duration")),
                f"{base}/{vid}{suffix}", published=_date(node.get("uploadDate") or node.get("datePublished")),
            ))
    return out


# ---------------------------------------------------------------------------------------------
# RSS / Atom feeds
# ---------------------------------------------------------------------------------------------

def _local(tag) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def feed_links(page_html: str, base_url: str) -> List[str]:
    """Feed addresses a page announces in its <head> (``<link rel="alternate" type="application/rss+xml">``)."""
    out = []
    for link in _soup(page_html).select("link[href][type]"):
        kind = (link.get("type") or "").lower()
        rel = " ".join(link.get("rel") or []).lower()
        if "alternate" in rel and ("rss" in kind or "atom" in kind):
            absolute = urljoin(base_url, link["href"])
            if absolute.startswith("https://"):
                out.append(absolute)
    return _distinct(out)[:2]


def _rfc822_date(value: str) -> Optional[str]:
    try:
        return parsedate_to_datetime(value).date().isoformat()
    except (TypeError, ValueError, IndexError):
        return _date(value)


def parse_feed(xml_text: str, base: str, hosts: Sequence[str], link_re, source_id: str, source_name: str,
               suffix: str = "", video_only: bool = True) -> List[Entry]:
    try:
        root = ET.fromstring((xml_text or "").lstrip("\ufeff").strip())
    except ET.ParseError:
        return []
    out: List[Entry] = []
    for item in (e for e in root.iter() if _local(e.tag) in ("item", "entry")):
        title = link = ""
        published = None
        for child in item:
            name = _local(child.tag)
            if name == "title" and not title:
                title = (child.text or "").strip()
            elif name == "link":
                rel = child.get("rel")
                candidate = (child.get("href") or child.text or "").strip()
                if candidate and (not link or rel in (None, "alternate")):
                    link = candidate
            elif name in ("pubDate", "published", "updated") and not published:
                published = _rfc822_date(child.text or "")
        descendants = list(item.iter())
        has_video, thumb, seconds = False, None, None
        for e in descendants:
            name = _local(e.tag)
            kind = (e.get("type") or "").lower()
            url = e.get("url") or ""
            if name in ("content", "enclosure") and (e.get("medium") == "video" or kind.startswith("video/")
                                                     or re.search(r"\.(?:mp4|m3u8|webm)(?:\?|$)", url, re.I)):
                has_video = True
                seconds = seconds or seconds_from_iso(e.get("duration"))
            elif name in ("content", "enclosure") and (e.get("medium") == "image" or kind.startswith("image/")):
                thumb = thumb or url
            elif name == "thumbnail" and url:
                thumb = thumb or url
            elif name == "duration" and e.text:
                seconds = seconds or seconds_from_iso(e.text)
        if not title or not link or not _host_ok(link, hosts) or looks_adult(title):
            continue
        path = urlparse(link).path
        matched = bool(link_re.match(path))
        if video_only and not (matched or has_video):
            continue
        vid = _page_id(path, link_re)
        if vid:
            out.append(_entry(source_id, source_name, vid, title[:200], source_name, thumb, seconds,
                              f"{base}/{vid}{suffix}", published=published))
    return out


# ---------------------------------------------------------------------------------------------
# One generic news site, configured by a few lines per site
# ---------------------------------------------------------------------------------------------

class NewsSite(GenericSite):
    """A news / science site read from its listing page(s) and feed. Only the first page is ever asked for (news
    listings have no stable paging), and the site has no live search: the catalogue search finds its stored videos."""

    paged = False
    prefer_ytdlp = True

    def __init__(self, source_id: str, name: str, description: str, hosts: Tuple[str, ...], list_urls: Tuple[str, ...],
                 link: str, *, suffix: str = "", feeds: Tuple[str, ...] = (), video_only: bool = True):
        self.source_id = source_id
        self.name = name
        self.description = f"{description} (web page + feed reading, no key; some videos play in the site's own player)"
        self.hosts = hosts
        self.list_urls = list_urls
        self.list_url = list_urls[0]
        self.link_re = re.compile(link)
        self.suffix = suffix
        self.feeds = feeds
        self.video_only = video_only

    def _from_page(self, html: str) -> List[Entry]:
        return _dedupe(
            parse_jsonld_videos(html, self.base, self.hosts, self.source_id, self.name, self.suffix)
            + self._cards(html)
        )

    def _from_feed(self, xml_text: str) -> List[Entry]:
        return parse_feed(xml_text, self.base, self.hosts, self.link_re, self.source_id, self.name, self.suffix,
                          self.video_only)

    def latest(self, page=1, limit=PER_PAGE):
        if page > 1:
            return []
        entries: List[Entry] = []
        first_error: Optional[Exception] = None
        announced: List[str] = []
        for url in self.list_urls:
            try:
                html = fetch_text(url, scrape=True)
            except Exception as exc:  # blocked by robots.txt, HTTP error, timeout ... (message is readable)
                first_error = first_error or exc
                continue
            entries = _dedupe(entries + self._from_page(html))
            announced += feed_links(html, url)
            if len(entries) >= ENOUGH:
                break
        if len(entries) < ENOUGH:
            for feed in _distinct(list(self.feeds) + announced)[:3]:
                try:
                    entries = _dedupe(entries + self._from_feed(fetch_text(feed, scrape=True)))
                except Exception as exc:
                    first_error = first_error or exc
                if len(entries) >= ENOUGH:
                    break
        if not entries:
            if first_error is not None:
                raise first_error
            raise SiteError(f"No videos found on the {self.name} page. The website may have changed its layout "
                            f"or may need JavaScript to show them.")
        return entries[:limit]

    def search(self, query, page=1, limit=PER_PAGE):
        return []  # no live search: /api/search also looks in the catalogue, which holds this site's scraped videos

    def video_id_from_url(self, url):
        p = urlparse(url)
        if p.scheme != "https" or p.netloc not in self.hosts:
            return None
        return _page_id(p.path, self.link_re)


# ---------------------------------------------------------------------------------------------
# NASA - official public API (https://images-api.nasa.gov), direct .mp4 files
# ---------------------------------------------------------------------------------------------

NASA_API = "https://images-api.nasa.gov"
NASA_TOPICS = ["space", "earth", "mars", "moon", "astronaut", "telescope", "rocket", "sun"]
NASA_ID = re.compile(r"^[A-Za-z0-9_.\-]{1,100}$")


def parse_nasa(text: str) -> List[Entry]:
    items = ((json.loads(text).get("collection") or {}).get("items")) or []
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        data = (item.get("data") or [{}])[0]
        nasa_id = data.get("nasa_id") or ""
        if data.get("media_type") != "video" or not NASA_ID.match(nasa_id) or looks_adult(data.get("title")):
            continue
        thumb = next((l.get("href") for l in item.get("links") or [] if l.get("rel") == "preview"), None)
        if thumb and thumb.startswith("http://"):
            thumb = "https://" + thumb[len("http://"):]
        out.append(_entry("nasa", "NASA", nasa_id, data.get("title") or "", data.get("center") or "NASA",
                          quote(thumb, safe=":/%~?&=") if thumb else None, None,
                          f"https://images.nasa.gov/details/{nasa_id}", published=_date(data.get("date_created"))))
    return out


def nasa_mp4_urls(text: str) -> List[str]:
    """The .mp4 files of one asset, phone-friendly first (medium, mobile, small), the huge original last."""
    items = ((json.loads(text).get("collection") or {}).get("items")) or []
    urls = [i.get("href") for i in items if isinstance(i, dict) and str(i.get("href", "")).lower().endswith(".mp4")]
    urls = ["https://" + u[len("http://"):] if u.startswith("http://") else u for u in urls]

    def rank(u: str) -> int:
        for n, tag in enumerate(("~medium", "~mobile", "~small", "~preview")):
            if tag in u:
                return n
        return 9 if "~orig" in u else 5

    return [quote(u, safe=":/%~") for u in sorted(_distinct(u for u in urls if u.startswith("https://")), key=rank)]


class NasaSite(Site):
    source_id = "nasa"
    name = "NASA"
    description = "NASA Image and Video Library - official public API, direct video files, no key"
    hosts = ("images.nasa.gov", "images-api.nasa.gov", "images-assets.nasa.gov")
    topic_based = True
    paged = True

    def _list(self, query: str, page: int, limit: int) -> List[Entry]:
        url = (f"{NASA_API}/search?q={quote_plus(query)}&media_type=video&page={max(1, page)}"
               f"&page_size={min(limit, 50)}&year_start={datetime.now(timezone.utc).year - 1}")
        return parse_nasa(fetch_text(url))

    def latest(self, page=1, limit=PER_PAGE):
        return self._list(NASA_TOPICS[(max(1, page) - 1) % len(NASA_TOPICS)], 1, limit)

    def search(self, query, page=1, limit=PER_PAGE):
        return self._list(query, page, limit) if query.strip() else []

    def video_id_from_url(self, url):
        p = urlparse(url)
        m = re.match(r"^/details[/-]([A-Za-z0-9_.\-]{1,100})/?$", p.path)
        return m.group(1) if p.netloc in self.hosts and m else None

    def resolve(self, video_id):
        if not NASA_ID.match(video_id):
            raise SiteError("Invalid NASA video.")
        urls = nasa_mp4_urls(fetch_text(f"{NASA_API}/asset/{quote(video_id)}"))
        if not urls:
            raise SiteError("NASA gave no video file for this item. Tap Retry or try another video.")
        return StreamInfo(urls=urls)


# ---------------------------------------------------------------------------------------------
# The 30 sites
# ---------------------------------------------------------------------------------------------

def _news(source_id, name, description, hosts, list_urls, link, **options) -> NewsSite:
    return NewsSite(source_id, name, description, tuple(hosts), tuple(list_urls), link, **options)


NEWS_SITES: List[Site] = [
    # ----- World news -----
    _news("reuters", "Reuters", "Reuters video news", ("www.reuters.com", "reuters.com"),
          ("https://www.reuters.com/video/",), r"^/(video/watch/[A-Za-z0-9_-]+)/?$"),
    _news("apnews", "Associated Press", "AP video news", ("apnews.com", "www.apnews.com"),
          ("https://apnews.com/video",), r"^/(video/[a-z0-9-]+)/?$"),
    _news("bbcnews", "BBC News", "BBC News video", ("www.bbc.com", "www.bbc.co.uk"),
          ("https://www.bbc.com/news", "https://www.bbc.com/video"),
          r"^/(news/(?:videos/[a-z0-9]{6,}|av/[a-z0-9-]+))/?$",
          feeds=("https://feeds.bbci.co.uk/news/video_and_audio/news_front_page/rss.xml",)),
    _news("dwnews", "DW News", "Deutsche Welle video", ("www.dw.com", "dw.com"),
          ("https://www.dw.com/en/media-center/videos/s-100825",), r"^/(en/[a-z0-9-]+/video-\d+)/?$"),
    _news("euronews", "Euronews", "Euronews video", ("www.euronews.com", "euronews.com"),
          ("https://www.euronews.com/video",), r"^/(video/\d{4}/\d{2}/\d{2}/[a-z0-9-]+)/?$"),
    _news("france24", "France 24", "France 24 video (English)", ("www.france24.com", "france24.com"),
          ("https://www.france24.com/en/video/",), r"^/(en/video/\d{8}-[a-z0-9-]+)/?$"),
    _news("aljazeera", "Al Jazeera", "Al Jazeera video", ("www.aljazeera.com", "aljazeera.com"),
          ("https://www.aljazeera.com/video/",), r"^/(video/[a-z0-9-]+/\d{4}/\d{1,2}/\d{1,2}/[a-z0-9-]+)/?$"),
    _news("skynews", "Sky News", "Sky News video", ("news.sky.com",),
          ("https://news.sky.com/watch",), r"^/(video/[a-z0-9-]+-\d{6,})/?$"),
    _news("cbcnews", "CBC News", "CBC News video", ("www.cbc.ca", "cbc.ca"),
          ("https://www.cbc.ca/news",), r"^/(player/play/(?:video/\d+\.\d+|\d{6,}))/?$"),
    _news("nhkworld", "NHK World", "NHK World-Japan video", ("www3.nhk.or.jp",),
          ("https://www3.nhk.or.jp/nhkworld/", "https://www3.nhk.or.jp/nhkworld/en/news/videos/"),
          r"^/(nhkworld/en/(?:news/videos/\d{10,}|ondemand/video/\d{6,}))/?$", suffix="/"),

    # ----- Space and Earth (NASA is its own class, above) -----
    NasaSite(),
    _news("esa", "ESA", "European Space Agency videos", ("www.esa.int",),
          ("https://www.esa.int/ESA_Multimedia/Videos",), r"^/(ESA_Multimedia/Videos/\d{4}/\d{2}/[A-Za-z0-9_]+)/?$"),
    _news("noaa", "NOAA", "NOAA videos", ("www.noaa.gov", "noaa.gov"),
          ("https://www.noaa.gov/",), r"^/((?:media|multimedia|video|videos)/[a-z0-9-]+(?:/[a-z0-9-]+)*)/?$"),

    # ----- Science -----
    _news("naturevideo", "Nature Video", "Nature video", ("www.nature.com",),
          ("https://www.nature.com/nature/videos",), r"^/(articles/d41586-\d{3}-\d{5}-\d)/?$"),
    _news("livescience", "Live Science", "Live Science", ("www.livescience.com", "livescience.com"),
          ("https://www.livescience.com/",), r"^/(videos?/[a-z0-9-]+)/?$"),
    _news("newscientist", "New Scientist", "New Scientist", ("www.newscientist.com", "newscientist.com"),
          ("https://www.newscientist.com/", "https://www.newscientist.com/video/"),
          r"^/(video/\d+-[a-z0-9-]+)/?$", suffix="/"),
    _news("sciencenews", "Science News", "Science News", ("www.sciencenews.org", "sciencenews.org"),
          ("https://www.sciencenews.org/",), r"^/(videos?/[a-z0-9-]+)/?$"),
    _news("smithsonian", "Smithsonian", "Smithsonian Institution videos", ("www.si.edu", "si.edu"),
          ("https://www.si.edu/", "https://www.si.edu/videos"), r"^/(videos/[a-z0-9-]+)/?$"),

    # ----- Explainers, nature and documentaries -----
    _news("wired", "WIRED", "WIRED video", ("www.wired.com", "wired.com"),
          ("https://www.wired.com/video/",), r"^/(video/watch/[a-z0-9-]+)/?$"),
    _news("vox", "Vox", "Vox videos", ("www.vox.com", "vox.com"),
          ("https://www.vox.com/videos",), r"^/(videos?/\d{6,}/[a-z0-9-]+)/?$"),
    _news("bbcearth", "BBC Earth", "BBC Earth videos", ("www.bbcearth.com", "bbcearth.com"),
          ("https://www.bbcearth.com/videos",), r"^/(videos/[a-z0-9-]+)/?$"),
    _news("natgeo", "National Geographic", "National Geographic video",
          ("www.nationalgeographic.com", "nationalgeographic.com"),
          ("https://www.nationalgeographic.com/video",), r"^/(video/(?:[a-z0-9-]+/){0,3}[a-z0-9-]+)/?$"),
    _news("pbs", "PBS", "PBS video", ("www.pbs.org", "pbs.org"),
          ("https://www.pbs.org/", "https://www.pbs.org/video/"), r"^/(video/[a-z0-9-]+)/?$", suffix="/"),
    _news("untv", "UN Web TV", "United Nations Web TV", ("webtv.un.org",),
          ("https://webtv.un.org/",), r"^/(en/asset/[a-z0-9]+/[a-z0-9]+)/?$"),
    _news("seatpants", "Exploring by the Seat of Your Pants", "Exploring by the Seat of Your Pants - daily dives",
          ("exploringbytheseat.com", "www.exploringbytheseat.com"),
          ("https://exploringbytheseat.com/daily-dives/",), r"^/(daily-dives/[a-z0-9-]+)/?$", suffix="/"),

    # ----- Talks and ideas -----
    _news("ted", "TED", "TED talks", ("www.ted.com", "ted.com"),
          ("https://www.ted.com/talks",), r"^/(talks/[a-z0-9_-]+)/?$"),
    _news("teded", "TED-Ed", "TED-Ed lessons", ("ed.ted.com",),
          ("https://ed.ted.com/videos", "https://ed.ted.com/lessons"), r"^/(lessons/[a-z0-9-]+)/?$"),
    _news("bigthink", "Big Think", "Big Think videos", ("bigthink.com", "www.bigthink.com"),
          ("https://bigthink.com/",), r"^/(series/[a-z0-9-]+/[a-z0-9-]+)/?$", suffix="/"),
    _news("npr", "NPR", "NPR video (Tiny Desk and more)", ("www.npr.org", "npr.org"),
          ("https://www.npr.org/", "https://www.npr.org/series/tiny-desk-concerts/"),
          r"^/(\d{4}/\d{2}/\d{2}/\d+/[a-z0-9-]*(?:tiny-desk|video)[a-z0-9-]*)/?$"),
    _news("guardian", "The Guardian", "The Guardian video", ("www.theguardian.com",),
          ("https://www.theguardian.com/video",), r"^/((?:[a-z-]+/)+video/\d{4}/[a-z]{3}/\d{1,2}/[a-z0-9-]+)/?$"),
]
