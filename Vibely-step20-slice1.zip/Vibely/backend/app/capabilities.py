"""Source capability matrix (Step 20).

For every site this says, in one place and honestly, what Vibely can do with it:

* how it plays (``direct_file`` / ``hls`` / ``web_player``),
* whether a video may be saved for offline use (``download``) and why / why not,
* whether audio-only export exists (it does not, for any site: nothing in Vibely extracts audio yet),
* what formats are expected and which metadata is always present.

Download policy is deliberately narrow: a site is ``allowed`` only when its clips are published under a
free licence meant for reuse (stock footage, Wikimedia Commons, NASA). Everything else is ``playback_only``
so the app shows no working-looking Download button for it. To change a decision edit ``_DOWNLOAD_ALLOWED``
below (the Android app mirrors it in ``DownloadPolicy.kt``; ``test_capabilities.py`` and ``DownloadPolicyTest``
keep both lists equal to the same ids).

This module imports nothing from the network layer, so it is cheap to import and easy to test.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Dict, Iterable, List, Optional, Tuple

DIRECT = "direct_file"
HLS = "hls"
WEB = "web_player"

# Sites whose clips come with a free reuse licence, so saving a copy offline is allowed.
# id -> (licence note, file formats)
_DOWNLOAD_ALLOWED: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "pexels": ("Pexels licence (free to use)", ("mp4",)),
    "pixabay": ("Pixabay content licence (free to use)", ("mp4",)),
    "mixkit": ("Mixkit free licence", ("mp4",)),
    "coverr": ("Coverr free licence", ("mp4",)),
    "wikimedia": ("Free licences on Wikimedia Commons (credit the author)", ("webm", "mp4")),
    "nasa": ("NASA media, mostly public domain (check the credit line)", ("mp4",)),
}

# How each site delivers video, from the README table (step 1 of the roadmap).
_DIRECT_ONLY = {
    "pexels", "pixabay", "mixkit", "coverr", "wikimedia", "nasa", "giphy", "tenor", "imgur", "videvo", "9gag",
}
_WEB_ONLY = {"dailymotion", "vimeo"}
_OFF_BY_DEFAULT = {"afv", "thedodo", "cheezburger"}
_NO_SOUND = {"giphy", "tenor", "imgur", "coverr", "pexels", "pixabay", "mixkit"}  # clips usually have no audio track

_AUDIO_REASON = "Audio-only export is not implemented in Vibely yet."
_PLAYBACK_ONLY_REASON = (
    "Playback only: this site's videos belong to their uploaders and the site gives no reuse licence, "
    "so Vibely offers no download."
)
ALWAYS_PRESENT_METADATA = ("title", "thumbnail", "page_url", "source_name")


@dataclass(frozen=True)
class Capability:
    source_id: str
    playable: bool
    playback_modes: Tuple[str, ...]
    download: str                       # "allowed" | "playback_only" | "disabled"
    downloadable_video: bool
    downloadable_audio: bool            # False everywhere: not implemented
    formats: Tuple[str, ...]            # file formats a download can have ([] when no download)
    metadata: Tuple[str, ...]           # fields that are always present (others only when the site gives them)
    licence_note: Optional[str]
    restrictions: Optional[str]         # why something is missing, in plain words
    audio_restrictions: str = _AUDIO_REASON

    def to_dict(self) -> dict:
        data = asdict(self)
        for key in ("playback_modes", "formats", "metadata"):
            data[key] = list(data[key])
        return data


def _modes(source_id: str, prefer_ytdlp: bool) -> Tuple[str, ...]:
    if source_id in _DIRECT_ONLY:
        return (DIRECT,)
    if source_id in _WEB_ONLY:
        return (WEB,)
    # Everything else tries a direct file / HLS first and falls back to the site's own web player.
    return (DIRECT, HLS, WEB)


def capability_for(source_id: str, prefer_ytdlp: bool = False, enabled: bool = True) -> Capability:
    modes = _modes(source_id, prefer_ytdlp)
    notes: List[str] = []
    if source_id in _OFF_BY_DEFAULT and not enabled:
        return Capability(
            source_id=source_id, playable=False, playback_modes=(), download="disabled",
            downloadable_video=False, downloadable_audio=False, formats=(), metadata=ALWAYS_PRESENT_METADATA,
            licence_note=None,
            restrictions="Off by default: most items are YouTube embeds, articles or memes that do not play. "
                         "Switch on with ENABLE_SITES.",
        )
    if source_id in _NO_SOUND:
        notes.append("Many clips have no audio track.")
    if prefer_ytdlp:
        notes.append("Some videos exist only as YouTube embeds and cannot be played.")
    if WEB in modes and DIRECT not in modes:
        notes.append("Plays only in the site's own web player.")
    allowed = _DOWNLOAD_ALLOWED.get(source_id)
    if allowed:
        licence, formats = allowed
        return Capability(
            source_id=source_id, playable=True, playback_modes=modes, download="allowed",
            downloadable_video=True, downloadable_audio=False, formats=formats,
            metadata=ALWAYS_PRESENT_METADATA, licence_note=licence,
            restrictions=" ".join(notes) or None,
        )
    notes.append(_PLAYBACK_ONLY_REASON)
    return Capability(
        source_id=source_id, playable=True, playback_modes=modes, download="playback_only",
        downloadable_video=False, downloadable_audio=False, formats=(), metadata=ALWAYS_PRESENT_METADATA,
        licence_note=None, restrictions=" ".join(notes),
    )


def build_matrix(sites: Iterable) -> Dict[str, Capability]:
    """One Capability per site object (needs ``source_id``, ``prefer_ytdlp`` and ``enabled()``)."""
    return {
        s.source_id: capability_for(s.source_id, bool(getattr(s, "prefer_ytdlp", False)), s.enabled())
        for s in sites
    }


def download_allowed_ids() -> List[str]:
    return sorted(_DOWNLOAD_ALLOWED)


def matrix_markdown(sites: Iterable) -> str:
    lines = [
        "| Site | Plays as | Download | Formats | Notes |",
        "| --- | --- | --- | --- | --- |",
    ]
    for s in sites:
        c = capability_for(s.source_id, bool(getattr(s, "prefer_ytdlp", False)), s.enabled())
        lines.append(
            f"| {s.name} (`{s.source_id}`) | {', '.join(c.playback_modes) or '-'} | {c.download} | "
            f"{', '.join(c.formats) or '-'} | {(c.licence_note or c.restrictions or '').replace('|', '/')} |"
        )
    return "\n".join(lines)


if __name__ == "__main__":  # python -m app.capabilities  -> prints the table used in docs/SOURCE_CAPABILITIES.md
    from app.scraping.sites import ALL_SITES

    print(matrix_markdown(ALL_SITES))
