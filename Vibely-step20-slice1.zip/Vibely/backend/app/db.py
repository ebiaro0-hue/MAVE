"""The video catalogue (Stage 1-2 "Database"): SQLite, one table. Only page addresses are stored, never stream links."""
from __future__ import annotations

import os
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, List, Optional

from app.scraping.models import Entry

SHORTS_SOURCES = ("pexels", "pixabay", "mixkit", "videvo", "coverr", "giphy", "tenor")   # short by nature
SHORTS_MAX_SECONDS = 120

SCHEMA = """
CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id TEXT NOT NULL,
    source_name TEXT NOT NULL,
    video_id TEXT NOT NULL,
    title TEXT NOT NULL,
    uploader TEXT NOT NULL DEFAULT '',
    thumbnail TEXT,
    page_url TEXT NOT NULL,
    published_date TEXT,
    duration_seconds INTEGER,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    UNIQUE (source_id, video_id)
);
CREATE INDEX IF NOT EXISTS idx_videos_source ON videos (source_id, first_seen);
CREATE TABLE IF NOT EXISTS source_status (
    source_id TEXT PRIMARY KEY,
    last_run TEXT,
    last_ok INTEGER,
    last_count INTEGER,
    last_error TEXT
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _like(token: str) -> str:
    escaped = token.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


class Store:
    def __init__(self, path: str = "data/vibely.db"):
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            if path != ":memory:":
                self._db.execute("PRAGMA journal_mode=WAL")
            self._db.executescript(SCHEMA)
            self._db.commit()

    # ----- writing -----

    def upsert(self, entries: Iterable[Entry]) -> int:
        now = _now()
        count = 0
        with self._lock:
            for e in entries:
                self._db.execute(
                    """INSERT INTO videos (source_id, source_name, video_id, title, uploader, thumbnail, page_url,
                                           published_date, duration_seconds, first_seen, last_seen)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT (source_id, video_id) DO UPDATE SET
                           title = excluded.title, uploader = excluded.uploader,
                           thumbnail = COALESCE(excluded.thumbnail, thumbnail), page_url = excluded.page_url,
                           published_date = COALESCE(excluded.published_date, published_date),
                           duration_seconds = COALESCE(excluded.duration_seconds, duration_seconds),
                           last_seen = excluded.last_seen""",
                    (e.source_id, e.source_name, e.video_id, e.title, e.uploader, e.thumbnail, e.page_url,
                     e.published_date, e.duration_seconds, now, now),
                )
                count += 1
            self._db.commit()
        return count

    def set_status(self, source_id: str, ok: bool, count: int, error: Optional[str]) -> None:
        with self._lock:
            self._db.execute(
                """INSERT INTO source_status (source_id, last_run, last_ok, last_count, last_error)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT (source_id) DO UPDATE SET last_run = excluded.last_run, last_ok = excluded.last_ok,
                       last_count = excluded.last_count, last_error = excluded.last_error""",
                (source_id, _now(), 1 if ok else 0, count, error),
            )
            self._db.commit()

    def prune(self, days: int = 30) -> int:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")
        with self._lock:
            cur = self._db.execute("DELETE FROM videos WHERE last_seen < ?", (cutoff,))
            self._db.commit()
            return cur.rowcount

    # ----- reading -----

    def _page(self, where: str, params: list, limit: int, offset: int) -> List[dict]:
        # Round-robin across sites (newest of each site first), so one busy site cannot fill the whole feed.
        sql = f"""SELECT * FROM (
                      SELECT v.*, ROW_NUMBER() OVER (PARTITION BY source_id ORDER BY first_seen DESC, id DESC) AS rn
                      FROM videos v WHERE {where}
                  ) ORDER BY rn, source_id LIMIT ? OFFSET ?"""
        with self._lock:
            rows = self._db.execute(sql, [*params, limit, offset]).fetchall()
        return [dict(r) for r in rows]

    def feed(self, limit: int = 20, offset: int = 0, source: Optional[str] = None, shorts: bool = False) -> List[dict]:
        clauses, params = ["1=1"], []
        if source:
            clauses.append("source_id = ?")
            params.append(source)
        if shorts:
            marks = ",".join("?" for _ in SHORTS_SOURCES)
            clauses.append(f"(source_id IN ({marks}) OR (duration_seconds IS NOT NULL AND duration_seconds <= ?))")
            params += [*SHORTS_SOURCES, SHORTS_MAX_SECONDS]
        return self._page(" AND ".join(clauses), params, limit, offset)

    def search(self, query: str, limit: int = 20, offset: int = 0, source: Optional[str] = None) -> List[dict]:
        """Every word must appear in the title, the uploader or the site name (so "rumble" lists Rumble videos)."""
        tokens = [t for t in query.split() if t][:5]
        clauses, params = ["1=1"], []
        if source:
            clauses.append("source_id = ?")
            params.append(source)
        for token in tokens:
            clauses.append("(title LIKE ? ESCAPE '\\' OR uploader LIKE ? ESCAPE '\\' OR source_name LIKE ? ESCAPE '\\')")
            params += [_like(token)] * 3
        return self._page(" AND ".join(clauses), params, limit, offset)

    def counts(self) -> Dict[str, int]:
        with self._lock:
            rows = self._db.execute("SELECT source_id, COUNT(*) AS n FROM videos GROUP BY source_id").fetchall()
        return {r["source_id"]: r["n"] for r in rows}

    def total(self) -> int:
        return sum(self.counts().values())

    def statuses(self) -> Dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM source_status").fetchall()
        return {r["source_id"]: dict(r) for r in rows}
