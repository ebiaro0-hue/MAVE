"""Stage 2 "Cron job": the scheduled scrape, plus the live search used by /api/search."""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Dict, List, Sequence, Tuple

from app.db import Store
from app.scraping.models import Entry
from app.scraping.sites import PER_PAGE, Site

log = logging.getLogger("vibely.jobs")

PAGES_PER_RUN = 2
LIVE_SEARCH_TIMEOUT = 12.0


def pages_for(site: Site, run: int) -> List[int]:
    """Topic-based sites get a different topic every run; API-style sites just refresh their first pages.
    A site that cannot page (``paged = False``) is asked for its first page only."""
    count = PAGES_PER_RUN if getattr(site, "paged", True) else 1
    if site.topic_based:
        return [run * count + i + 1 for i in range(count)]
    return [i + 1 for i in range(count)]


def due(site: Site, run: int) -> bool:
    """Sites with a small free quota (``scrape_every`` > 1) are scraped only every N-th run; run 0 always scrapes."""
    return run == 0 or run % max(1, getattr(site, "scrape_every", 1)) == 0


def usable(site: Site) -> bool:
    """False for sites still waiting for their free key (or switched off by default)."""
    return getattr(site, "enabled", lambda: True)()


def interleave(lists: Sequence[Sequence[Entry]]) -> List[Entry]:
    """Round-robin merge; duplicates (same site + id) are dropped."""
    out: List[Entry] = []
    seen = set()
    i = 0
    while any(i < len(items) for items in lists):
        for items in lists:
            if i < len(items):
                key = (items[i].source_id, items[i].video_id)
                if key not in seen:
                    seen.add(key)
                    out.append(items[i])
        i += 1
    return out


def scrape_all(store: Store, sites: Sequence[Site], run: int = 0, limit: int = PER_PAGE, workers: int = 8) -> Dict[str, dict]:
    """Reads the newest videos of every site and stores them. One site failing never stops the others."""
    sites = [s for s in sites if usable(s) and due(s, run)]
    summary: Dict[str, dict] = {s.source_id: {"count": 0, "error": None} for s in sites}

    def work(site: Site, page: int) -> Tuple[str, List[Entry], str]:
        try:
            return site.source_id, site.latest(page, limit), ""
        except Exception as exc:
            return site.source_id, [], str(exc) or exc.__class__.__name__

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(work, site, page) for site in sites for page in pages_for(site, run)]
        results = [f.result() for f in futures]

    for site in sites:
        entries: List[Entry] = []
        errors: List[str] = []
        for source_id, found, error in results:
            if source_id != site.source_id:
                continue
            entries += found
            if error:
                errors.append(error)
        stored = store.upsert(entries)
        ok = stored > 0 or not errors
        error_text = None if ok else "; ".join(dict.fromkeys(errors))[:300]
        store.set_status(site.source_id, ok, stored, error_text)
        summary[site.source_id] = {"count": stored, "error": error_text}
        if error_text:
            log.warning("scrape %s failed: %s", site.source_id, error_text)
    return summary


def search_live(sites: Sequence[Site], query: str, page: int, limit: int = PER_PAGE,
                timeout: float = LIVE_SEARCH_TIMEOUT) -> Tuple[List[List[Entry]], List[str]]:
    """Asks the sites at the same time. Slow or failing sites are left out and named in the second result."""
    sites = [s for s in sites if usable(s)]
    if not sites:
        return [], []
    pool = ThreadPoolExecutor(max_workers=len(sites))
    futures = {pool.submit(site.search, query, page, limit): site for site in sites}
    done, not_done = wait(list(futures), timeout=timeout)
    pool.shutdown(wait=False, cancel_futures=True)
    lists: List[List[Entry]] = []
    failed: List[str] = [futures[f].name for f in not_done]
    for site in sites:
        future = next((f for f, s in futures.items() if s is site), None)
        if future in done:
            try:
                lists.append(future.result())
            except Exception as exc:
                log.warning("search %s failed: %s", site.source_id, exc)
                failed.append(site.name)
    return lists, failed
