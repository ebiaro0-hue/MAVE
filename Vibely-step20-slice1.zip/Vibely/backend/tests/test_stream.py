from app.scraping import stream as st
from app.scraping.models import StreamInfo
from app.scraping.sites import SITES_BY_ID, SiteError
from app.scraping.stream import StreamError, host_blocked, pick_from_info, resolve_stream


def _fail(url):
    raise AssertionError("yt-dlp should not have been asked")


def _error_of(fn):
    try:
        fn()
    except StreamError as exc:
        return exc
    raise AssertionError("expected StreamError")


def test_youtube_and_friends_are_blocked():
    for host in ("youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtube-nocookie.com"):
        assert host_blocked(host)
    assert not host_blocked("notyoutube.com") and not host_blocked("rumble.com")
    assert _error_of(lambda: resolve_stream("https://www.youtube.com/watch?v=abcdefghijk", _fail)).status == 403


def test_only_https_and_allowlisted_hosts():
    assert _error_of(lambda: resolve_stream("http://rumble.com/v6abc12-x.html", _fail)).status == 400
    assert _error_of(lambda: resolve_stream("not a url", _fail)).status == 400
    assert _error_of(lambda: resolve_stream("https://example.org/video", _fail)).status == 403


def test_extra_hosts_from_the_environment_go_to_ytdlp():
    import os
    os.environ["EXTRA_STREAM_HOSTS"] = "videos.example.org"
    try:
        info = {"url": "https://cdn.example.org/a.mp4"}
        out = resolve_stream("https://videos.example.org/watch/1", lambda u: info)
        assert out["media_url"] == "https://cdn.example.org/a.mp4" and out["source_id"] == "videos.example.org"
    finally:
        del os.environ["EXTRA_STREAM_HOSTS"]


def test_site_extractor_is_used_first():
    site = SITES_BY_ID["rumble"]
    original = site.resolve_url
    site.resolve_url = lambda url: StreamInfo(urls=["https://r/720.mp4"], embed_url="https://rumble.com/embed/v5abcd/")
    try:
        out = resolve_stream("https://rumble.com/v6abc12-funny-cats.html", _fail)
    finally:
        site.resolve_url = original
    assert out["media_url"] == "https://r/720.mp4" and out["media_urls"] == ["https://r/720.mp4"]
    assert out["embed_url"] == "https://rumble.com/embed/v5abcd/" and out["source_id"] == "rumble"


def test_web_player_only_answer_is_enough():
    out = resolve_stream("https://www.dailymotion.com/video/x8abc12", _fail)
    assert out["media_url"] is None and out["media_urls"] == []
    assert out["embed_url"] == "https://www.dailymotion.com/embed/video/x8abc12?autoplay=1"


def test_ytdlp_is_the_fallback_when_the_site_extractor_finds_nothing():
    site = SITES_BY_ID["rumble"]
    original = site.resolve_url

    def broken(url):
        raise SiteError("Could not find the Rumble player for this video.")

    site.resolve_url = broken
    try:
        info = {"formats": [{"url": "https://c/v.mp4", "ext": "mp4", "protocol": "https", "vcodec": "avc1", "acodec": "mp4a", "height": 720}]}
        out = resolve_stream("https://rumble.com/v6abc12-funny-cats.html", lambda u: info)
        assert out["media_url"] == "https://c/v.mp4"
        err = _error_of(lambda: resolve_stream("https://rumble.com/v6abc12-funny-cats.html", lambda u: {}))
        assert err.status == 404 and "Rumble player" in str(err)
    finally:
        site.resolve_url = original


def test_pick_from_info_prefers_progressive_mp4_then_hls_and_skips_drm_and_video_only():
    info = {"formats": [
        {"url": "https://c/1080.mp4", "ext": "mp4", "protocol": "https", "vcodec": "avc1", "acodec": "aac", "height": 1080},
        {"url": "https://c/480.mp4", "ext": "mp4", "protocol": "https", "vcodec": "avc1", "acodec": "aac", "height": 480},
        {"url": "https://c/720.mp4", "ext": "mp4", "protocol": "https", "vcodec": "avc1", "acodec": "aac", "height": 720},
        {"url": "https://c/video-only.mp4", "ext": "mp4", "protocol": "https", "vcodec": "avc1", "acodec": "none", "height": 720},
        {"url": "https://c/drm.mp4", "ext": "mp4", "protocol": "https", "vcodec": "avc1", "acodec": "aac", "height": 720, "has_drm": True},
        {"url": "https://c/dash.mp4", "ext": "mp4", "protocol": "http_dash_segments", "vcodec": "avc1", "acodec": "aac", "height": 360},
        {"url": "http://c/insecure.mp4", "ext": "mp4", "protocol": "http", "vcodec": "avc1", "acodec": "aac", "height": 360},
        {"url": "https://c/master.m3u8", "ext": "mp4", "protocol": "m3u8_native", "vcodec": "avc1", "acodec": "aac", "height": 720},
    ]}
    assert pick_from_info(info).urls == ["https://c/720.mp4", "https://c/480.mp4", "https://c/1080.mp4", "https://c/master.m3u8"]
    assert pick_from_info({"url": "https://c/single.mp4"}).urls == ["https://c/single.mp4"]
    assert pick_from_info({"url": "https://c/single.mp4", "has_drm": True}).urls == []
    assert pick_from_info({}).urls == []
