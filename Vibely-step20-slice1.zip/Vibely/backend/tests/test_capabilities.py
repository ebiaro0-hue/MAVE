"""Step 20: the capability matrix must describe every site, honestly and consistently."""
from app.capabilities import (
    DIRECT, WEB, ALWAYS_PRESENT_METADATA, build_matrix, capability_for, download_allowed_ids, matrix_markdown,
)
from app.scraping.sites import ALL_SITES

ANDROID_ALLOWED = {"pexels", "pixabay", "mixkit", "coverr", "wikimedia", "nasa"}  # same ids as DownloadPolicy.kt


def test_every_site_has_a_capability():
    matrix = build_matrix(ALL_SITES)
    assert set(matrix) == {s.source_id for s in ALL_SITES}


def test_download_ids_match_android_policy_and_exist():
    assert set(download_allowed_ids()) == ANDROID_ALLOWED
    ids = {s.source_id for s in ALL_SITES}
    assert ANDROID_ALLOWED <= ids


def test_no_audio_download_anywhere_because_it_is_not_implemented():
    for cap in build_matrix(ALL_SITES).values():
        assert cap.downloadable_audio is False
        assert "not implemented" in cap.audio_restrictions


def test_allowed_sites_have_formats_and_licence():
    for sid in ANDROID_ALLOWED:
        cap = capability_for(sid)
        assert cap.download == "allowed" and cap.downloadable_video
        assert cap.formats and cap.licence_note


def test_playback_only_sites_offer_no_download_and_say_why():
    for sid in ("rumble", "vimeo", "ted", "giphy", "bitchute"):
        cap = capability_for(sid)
        assert cap.download == "playback_only"
        assert not cap.downloadable_video and cap.formats == ()
        assert cap.restrictions and "download" in cap.restrictions.lower()


def test_playback_modes():
    assert capability_for("pexels").playback_modes == (DIRECT,)
    assert capability_for("vimeo").playback_modes == (WEB,)
    assert DIRECT in capability_for("rumble").playback_modes and WEB in capability_for("rumble").playback_modes


def test_sites_that_are_off_by_default_are_not_playable():
    off = [s for s in ALL_SITES if not s.enabled()]
    assert {s.source_id for s in off} == {"afv", "thedodo", "cheezburger"}
    for s in off:
        cap = capability_for(s.source_id, enabled=False)
        assert cap.download == "disabled" and not cap.playable and cap.playback_modes == ()


def test_youtube_embed_warning_for_ytdlp_sites():
    assert "YouTube" in capability_for("reuters", prefer_ytdlp=True).restrictions


def test_always_present_metadata_only_lists_what_every_entry_has():
    assert set(ALWAYS_PRESENT_METADATA) == {"title", "thumbnail", "page_url", "source_name"}
    assert "view_count" not in ALWAYS_PRESENT_METADATA  # never invented


def test_to_dict_is_json_friendly_and_markdown_lists_every_site():
    import json
    d = capability_for("pexels").to_dict()
    json.dumps(d)
    assert isinstance(d["playback_modes"], list)
    table = matrix_markdown(ALL_SITES)
    assert table.count("\n") == len(ALL_SITES) + 1
