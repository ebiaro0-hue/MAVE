import json

import pytest

from app.scraping.sites import ALL_SITES, SITES_BY_ID, SiteError, site_for_host
from app.scraping.models import StreamInfo
from app.scraping import sites_more, sites_news
from app.scraping.sites_news import (
    NEWS_SITES, NasaSite, NewsSite, feed_links, nasa_mp4_urls, parse_feed, parse_jsonld_videos, parse_nasa,
    seconds_from_iso,
)
from app.scraping.stream import resolve_stream

# The 30 sites that were asked for: (source id, a listing address, a real-looking video page, a page that is NOT a video)
REQUESTED = [
    ("reuters", "https://www.reuters.com/video/", "https://www.reuters.com/video/watch/idRW123456789", "https://www.reuters.com/video/"),
    ("apnews", "https://apnews.com/video", "https://apnews.com/video/storm-hits-coast-0123456789abcdef", "https://apnews.com/video"),
    ("bbcnews", "https://www.bbc.com/news", "https://www.bbc.com/news/videos/c1234abcd5xo", "https://www.bbc.com/news/world"),
    ("dwnews", "https://www.dw.com/en/media-center/videos/s-100825", "https://www.dw.com/en/floods-in-europe/video-68123456", "https://www.dw.com/en/media-center/videos/s-100825"),
    ("euronews", "https://www.euronews.com/video", "https://www.euronews.com/video/2026/11/20/climate-talks-open", "https://www.euronews.com/video"),
    ("france24", "https://www.france24.com/en/video/", "https://www.france24.com/en/video/20261120-election-night", "https://www.france24.com/en/video/"),
    ("aljazeera", "https://www.aljazeera.com/video/", "https://www.aljazeera.com/video/newsfeed/2026/11/20/aid-arrives", "https://www.aljazeera.com/video/"),
    ("skynews", "https://news.sky.com/watch", "https://news.sky.com/video/storm-damage-13123456", "https://news.sky.com/watch"),
    ("cbcnews", "https://www.cbc.ca/news", "https://www.cbc.ca/player/play/video/9.6955433", "https://www.cbc.ca/news/canada"),
    ("nhkworld", "https://www3.nhk.or.jp/nhkworld/", "https://www3.nhk.or.jp/nhkworld/en/news/videos/20261120110000/", "https://www3.nhk.or.jp/nhkworld/en/news/"),
    ("esa", "https://www.esa.int/ESA_Multimedia/Videos", "https://www.esa.int/ESA_Multimedia/Videos/2026/11/Launch_day", "https://www.esa.int/ESA_Multimedia/Videos"),
    ("noaa", "https://www.noaa.gov/", "https://www.noaa.gov/media/hurricane-season-wrap", "https://www.noaa.gov/"),
    ("naturevideo", "https://www.nature.com/nature/videos", "https://www.nature.com/articles/d41586-026-01234-5", "https://www.nature.com/nature/videos"),
    ("livescience", "https://www.livescience.com/", "https://www.livescience.com/video/deep-sea-octopus", "https://www.livescience.com/"),
    ("newscientist", "https://www.newscientist.com/", "https://www.newscientist.com/video/2420000-why-whales-sing/", "https://www.newscientist.com/video/"),
    ("sciencenews", "https://www.sciencenews.org/", "https://www.sciencenews.org/video/tiny-robots", "https://www.sciencenews.org/"),
    ("smithsonian", "https://www.si.edu/", "https://www.si.edu/videos/lost-cities", "https://www.si.edu/videos"),
    ("wired", "https://www.wired.com/video/", "https://www.wired.com/video/watch/inside-the-lab", "https://www.wired.com/video/"),
    ("vox", "https://www.vox.com/videos", "https://www.vox.com/videos/23988888/why-prices-rise", "https://www.vox.com/videos"),
    ("bbcearth", "https://www.bbcearth.com/videos", "https://www.bbcearth.com/videos/lion-pride-hunt", "https://www.bbcearth.com/videos"),
    ("natgeo", "https://www.nationalgeographic.com/video", "https://www.nationalgeographic.com/video/shows/wild-nile", "https://www.nationalgeographic.com/video"),
    ("pbs", "https://www.pbs.org/", "https://www.pbs.org/video/ocean-giants-abc123/", "https://www.pbs.org/video/"),
    ("untv", "https://webtv.un.org/", "https://webtv.un.org/en/asset/k1x/k1x6abc123", "https://webtv.un.org/en/ondemand"),
    ("seatpants", "https://exploringbytheseat.com/daily-dives/", "https://exploringbytheseat.com/daily-dives/dive-1204/", "https://exploringbytheseat.com/daily-dives/"),
    ("ted", "https://www.ted.com/talks", "https://www.ted.com/talks/jane_doe_how_to_listen", "https://www.ted.com/talks"),
    ("teded", "https://ed.ted.com/videos", "https://ed.ted.com/lessons/why-do-we-dream", "https://ed.ted.com/lessons"),
    ("bigthink", "https://bigthink.com/", "https://bigthink.com/series/the-big-idea/what-is-time/", "https://bigthink.com/series/the-big-idea/"),
    ("npr", "https://www.npr.org/", "https://www.npr.org/2026/11/20/1200000000/tiny-desk-concert-example", "https://www.npr.org/2026/11/20/1200000000/budget-talks"),
    ("guardian", "https://www.theguardian.com/video", "https://www.theguardian.com/world/video/2026/nov/20/floods-in-spain", "https://www.theguardian.com/video"),
]


def test_all_30_requested_sites_are_registered_and_the_old_ones_are_untouched():
    ids = [s.source_id for s in ALL_SITES]
    assert len(ids) == len(set(ids))
    assert len(NEWS_SITES) == 30 and len(REQUESTED) == 29          # NASA is the 30th (its own test below)
    for source_id, listing, *_ in REQUESTED:
        site = SITES_BY_ID[source_id]
        assert site_for_host(sites_news.urlparse(listing).netloc) is site, source_id
        assert len(source_id) <= 30                                # /api/videos?source=... accepts up to 30 characters
    assert site_for_host("images.nasa.gov") is SITES_BY_ID["nasa"]
    for old in ("pexels", "pixabay", "mixkit", "rumble", "odysee", "peertube", "vimeo", "dailymotion", "bitchute",
                "giphy", "coverr", "wikimedia"):
        assert old in SITES_BY_ID


def test_every_site_recognises_its_video_pages_and_not_its_listings():
    for source_id, listing, video, other in REQUESTED:
        site = SITES_BY_ID[source_id]
        assert site.video_id_from_url(video), (source_id, "video page not recognised")
        path = sites_news.urlparse(other).path
        assert not site.link_re.match(path), (source_id, "listing/article wrongly taken for a video")


def test_video_id_from_url_stays_on_the_site_and_rejects_odd_paths():
    ted = SITES_BY_ID["ted"]
    assert ted.video_id_from_url("https://www.ted.com/talks/jane_doe_how_to_listen?language=en") == "talks/jane_doe_how_to_listen"
    assert ted.video_id_from_url("https://evil.example/talks/x") is None
    assert ted.video_id_from_url("http://www.ted.com/talks/x") is None
    assert ted.video_id_from_url("https://www.ted.com/talks/../../etc") is None


def test_iso_durations():
    assert seconds_from_iso("PT1M30S") == 90 and seconds_from_iso("PT2H") == 7200 and seconds_from_iso("PT1H2M3S") == 3723
    assert seconds_from_iso(125) == 125 and seconds_from_iso("3:21") == 201 and seconds_from_iso("42") == 42
    assert seconds_from_iso("") is None and seconds_from_iso("nonsense") is None and seconds_from_iso(0) is None


LISTING_WITH_JSONLD = """
<html><head>
<link rel="alternate" type="application/rss+xml" href="/rss/video.xml">
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[
 {"@type":"VideoObject","name":"Floods hit the coast","url":"https://www.dw.com/en/floods/video-68000001",
  "thumbnailUrl":["https://static.dw.com/a.jpg"],"duration":"PT2M5S","uploadDate":"2026-11-20T08:00:00Z"},
 {"@type":"VideoObject","name":"Other host","url":"https://other.example/v/1"},
 {"@type":"VideoObject","name":"No url"}]}</script></head><body>
<a href="/en/summit-opens/video-68000002"><img src="/img/s.jpg"><h3>Summit opens</h3></a>
<a href="/en/some-article/a-68000003">An article, not a video</a>
</body></html>"""


def test_jsonld_video_objects_become_entries_only_for_the_same_site():
    entries = parse_jsonld_videos(LISTING_WITH_JSONLD, "https://www.dw.com", ("www.dw.com", "dw.com"), "dwnews", "DW News")
    assert [e.video_id for e in entries] == ["en/floods/video-68000001"]
    e = entries[0]
    assert e.title == "Floods hit the coast" and e.duration_seconds == 125 and e.published_date == "2026-11-20"
    assert e.thumbnail == "https://static.dw.com/a.jpg" and e.page_url == "https://www.dw.com/en/floods/video-68000001"


def test_page_gives_jsonld_videos_plus_link_cards_without_duplicates():
    entries = SITES_BY_ID["dwnews"]._from_page(LISTING_WITH_JSONLD)
    assert [e.video_id for e in entries] == ["en/floods/video-68000001", "en/summit-opens/video-68000002"]
    assert feed_links(LISTING_WITH_JSONLD, "https://www.dw.com/en/x") == ["https://www.dw.com/rss/video.xml"]


RSS = """<?xml version="1.0"?><rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/"
 xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"><channel>
<item><title>Video report</title><link>https://www.bbc.co.uk/news/videos/c1234abcd5xo?at=rss</link>
 <pubDate>Thu, 20 Nov 2026 10:00:00 GMT</pubDate><media:thumbnail url="https://ichef.bbci.co.uk/t.jpg"/>
 <media:content url="https://x/y.mp4" medium="video" duration="75"/></item>
<item><title>Clip with a file</title><link>https://www.bbc.com/news/world-12345678</link>
 <media:content url="https://x/clip.mp4" type="video/mp4"/><itunes:duration>1:05</itunes:duration></item>
<item><title>Plain article</title><link>https://www.bbc.com/news/world-99999999</link></item>
<item><title>Foreign link</title><link>https://elsewhere.example/news/videos/c1234abcd5xo</link></item>
</channel></rss>"""

ATOM = """<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Atom video</title>
<link rel="alternate" href="https://www.theguardian.com/world/video/2026/nov/20/floods-in-spain"/>
<published>2026-11-20T09:00:00Z</published></entry></feed>"""


def test_feed_keeps_only_video_items_of_the_site():
    bbc = SITES_BY_ID["bbcnews"]
    entries = parse_feed(RSS, bbc.base, bbc.hosts, bbc.link_re, "bbcnews", "BBC News")
    assert [e.title for e in entries] == ["Video report", "Clip with a file"]
    first, second = entries
    assert first.video_id == "news/videos/c1234abcd5xo" and first.duration_seconds == 75
    assert first.published_date == "2026-11-20" and first.thumbnail == "https://ichef.bbci.co.uk/t.jpg"
    assert first.page_url == "https://www.bbc.com/news/videos/c1234abcd5xo"
    assert second.duration_seconds == 65
    everything = parse_feed(RSS, bbc.base, bbc.hosts, bbc.link_re, "bbcnews", "BBC News", video_only=False)
    assert len(everything) == 3                                     # the foreign-host item is never kept


def test_atom_feed_and_broken_xml():
    g = SITES_BY_ID["guardian"]
    entries = parse_feed(ATOM, g.base, g.hosts, g.link_re, "guardian", "The Guardian")
    assert len(entries) == 1 and entries[0].published_date == "2026-11-20"
    assert parse_feed("<html><body>not xml", g.base, g.hosts, g.link_re, "guardian", "The Guardian") == []


def test_adult_titles_are_filtered_from_feeds():
    feed = RSS.replace("Video report", "Nude beach party")
    bbc = SITES_BY_ID["bbcnews"]
    assert "Nude beach party" not in [e.title for e in parse_feed(feed, bbc.base, bbc.hosts, bbc.link_re, "bbcnews", "BBC News")]


# ----- latest(): page -> feed -> errors -----

def _patch_fetch(monkeypatch, pages):
    """pages: {url: text or Exception}. Patches the fetcher used by sites_news (and sites_more for resolve)."""
    calls = []

    def fake(url, **kwargs):
        calls.append(url)
        result = pages.get(url)
        if result is None:
            raise sites_news.SiteError("HTTP 404")
        if isinstance(result, Exception):
            raise result
        return result

    monkeypatch.setattr(sites_news, "fetch_text", fake)
    monkeypatch.setattr(sites_more, "fetch_text", fake)
    return calls


def test_latest_reads_the_listing_page_and_stops_when_it_has_enough(monkeypatch):
    cards = "".join(f'<a href="/en/story-{i}/video-6800{i:04d}"><h3>Story {i}</h3></a>' for i in range(8))
    calls = _patch_fetch(monkeypatch, {"https://www.dw.com/en/media-center/videos/s-100825": cards})
    entries = SITES_BY_ID["dwnews"].latest(1, 20)
    assert len(entries) == 8 and entries[0].source_id == "dwnews" and calls == ["https://www.dw.com/en/media-center/videos/s-100825"]
    assert SITES_BY_ID["dwnews"].latest(2, 20) == []                 # news listings have no paging


def test_latest_falls_back_to_the_feed_when_the_page_has_no_videos(monkeypatch):
    bbc = SITES_BY_ID["bbcnews"]
    _patch_fetch(monkeypatch, {
        "https://www.bbc.com/news": "<html><body>rendered by JavaScript</body></html>",
        "https://www.bbc.com/video": "<html></html>",
        bbc.feeds[0]: RSS,
    })
    entries = bbc.latest(1, 20)
    assert [e.title for e in entries] == ["Video report", "Clip with a file"]


def test_latest_uses_a_feed_that_the_page_announces(monkeypatch):
    guardian = SITES_BY_ID["guardian"]
    page = '<html><head><link rel="alternate" type="application/rss+xml" href="https://www.theguardian.com/video/rss"></head></html>'
    _patch_fetch(monkeypatch, {"https://www.theguardian.com/video": page, "https://www.theguardian.com/video/rss": ATOM})
    assert [e.video_id for e in guardian.latest(1, 20)] == ["world/video/2026/nov/20/floods-in-spain"]


def test_latest_reports_why_a_site_gave_nothing(monkeypatch):
    from app.scraping.polite import FetchError
    _patch_fetch(monkeypatch, {"https://www.reuters.com/video/": FetchError("www.reuters.com does not allow automatic reading of this page.")})
    with pytest.raises(Exception) as err:
        SITES_BY_ID["reuters"].latest(1, 20)
    assert "does not allow automatic reading" in str(err.value)
    _patch_fetch(monkeypatch, {"https://www.reuters.com/video/": "<html>empty</html>"})
    with pytest.raises(SiteError) as err2:
        SITES_BY_ID["reuters"].latest(1, 20)
    assert "No videos found" in str(err2.value)


def test_live_search_is_left_to_the_catalogue():
    assert SITES_BY_ID["wired"].search("robots") == []


# ----- playing -----

def test_resolve_finds_a_direct_file_on_the_video_page(monkeypatch):
    page = '<meta property="og:video" content="https://cdn.dw.com/clip-720.mp4"><title>x</title>'
    _patch_fetch(monkeypatch, {"https://www.dw.com/en/floods/video-68000001": page})
    info = SITES_BY_ID["dwnews"].resolve_url("https://www.dw.com/en/floods/video-68000001")
    assert info.urls == ["https://cdn.dw.com/clip-720.mp4"]


def test_resolve_says_so_when_the_only_player_is_youtube(monkeypatch):
    page = '<iframe src="https://www.youtube.com/embed/abcdefghijk"></iframe>'
    _patch_fetch(monkeypatch, {"https://www.bbcearth.com/videos/lion-pride-hunt": page})
    with pytest.raises(SiteError) as err:
        SITES_BY_ID["bbcearth"].resolve_url("https://www.bbcearth.com/videos/lion-pride-hunt")
    assert "YouTube" in str(err.value)


def test_stream_endpoint_logic_asks_ytdlp_when_the_page_has_no_file(monkeypatch):
    _patch_fetch(monkeypatch, {"https://www.bbc.com/news/videos/c1234abcd5xo": "<html>player loads later</html>"})
    info = {"formats": [{"url": "https://cdn.bbc/720.mp4", "vcodec": "avc1", "acodec": "aac", "protocol": "https", "ext": "mp4", "height": 720}]}
    out = resolve_stream("https://www.bbc.com/news/videos/c1234abcd5xo", lambda url: info)
    assert out["source_id"] == "bbcnews" and out["media_url"] == "https://cdn.bbc/720.mp4"


def test_youtube_is_still_blocked_and_unknown_hosts_still_refused():
    from app.scraping.stream import StreamError
    for url, status in (("https://www.youtube.com/watch?v=abcdefghijk", 403), ("https://example.org/video", 403)):
        with pytest.raises(StreamError) as err:
            resolve_stream(url, lambda u: {})
        assert err.value.status == status


# ----- NASA (official API) -----

NASA_SEARCH = json.dumps({"collection": {"items": [
    {"href": "https://images-assets.nasa.gov/video/Apollo 11 Landing/collection.json",
     "data": [{"nasa_id": "Apollo 11 Landing", "title": "Apollo 11 Landing", "center": "JSC", "media_type": "video",
               "date_created": "1969-07-20T00:00:00Z"}]},
    {"href": "x", "data": [{"nasa_id": "GSFC_20260101_Sun", "title": "The Sun in motion", "center": "GSFC", "media_type": "video",
                            "date_created": "2026-01-01T00:00:00Z"}],
     "links": [{"href": "http://images-assets.nasa.gov/video/GSFC_20260101_Sun/GSFC_20260101_Sun~thumb.jpg", "rel": "preview"}]},
    {"href": "y", "data": [{"nasa_id": "pic1", "title": "A photo", "media_type": "image"}]},
]}})

NASA_ASSET = json.dumps({"collection": {"items": [
    {"href": "http://images-assets.nasa.gov/video/GSFC_20260101_Sun/GSFC_20260101_Sun~orig.mp4"},
    {"href": "http://images-assets.nasa.gov/video/GSFC_20260101_Sun/GSFC_20260101_Sun~medium.mp4"},
    {"href": "http://images-assets.nasa.gov/video/GSFC_20260101_Sun/GSFC_20260101_Sun~small.mp4"},
    {"href": "http://images-assets.nasa.gov/video/GSFC_20260101_Sun/GSFC_20260101_Sun.srt"},
]}})


def test_nasa_search_and_files():
    entries = parse_nasa(NASA_SEARCH)
    assert [e.video_id for e in entries] == ["GSFC_20260101_Sun"]     # the id with a space and the photo are skipped
    e = entries[0]
    assert e.thumbnail.startswith("https://") and e.published_date == "2026-01-01" and e.page_url == "https://images.nasa.gov/details/GSFC_20260101_Sun"
    urls = nasa_mp4_urls(NASA_ASSET)
    assert [u.rsplit("~", 1)[1] for u in urls] == ["medium.mp4", "small.mp4", "orig.mp4"] and all(u.startswith("https://") for u in urls)


def test_nasa_site_calls_the_api(monkeypatch):
    seen = []

    def fake(url, **kwargs):
        seen.append(url)
        return NASA_ASSET if "/asset/" in url else NASA_SEARCH

    monkeypatch.setattr(sites_news, "fetch_text", fake)
    nasa = SITES_BY_ID["nasa"]
    assert isinstance(nasa, NasaSite) and nasa.latest(1)[0].source_id == "nasa"
    assert "media_type=video" in seen[0] and "q=space" in seen[0]
    assert nasa.search("moon landing")[0].title == "The Sun in motion" and "q=moon+landing" in seen[1]
    assert nasa.search("  ") == []
    assert nasa.video_id_from_url("https://images.nasa.gov/details/GSFC_20260101_Sun") == "GSFC_20260101_Sun"
    assert nasa.resolve("GSFC_20260101_Sun").urls[0].endswith("~medium.mp4")
    with pytest.raises(SiteError):
        nasa.resolve("../../etc/passwd")
