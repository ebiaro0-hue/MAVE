import json
import os

from app.jobs import due, pages_for, scrape_all, search_live
from app.db import Store
from app.scraping.models import StreamInfo
from app.scraping.sites import ALL_SITES, PEERTUBE_INSTANCES, SITES_BY_ID, SiteError, site_for_host
from app.scraping import sites_more
from app.scraping.sites_more import (
    AfvSite, CoverrSite, DTubeSite, EbaumsworldSite, GiphySite, ImgurSite, TenorSite, VidevoSite,
    looks_adult, parse_9gag, parse_bitchute, parse_giphy_page, parse_imgur_page, parse_tenor_page,
    parse_wp_posts, sniff_page, BitChuteSite, NineGagSite, FailArmySite,
)


def test_all_requested_sites_are_registered_once():
    ids = [s.source_id for s in ALL_SITES]
    assert len(ids) == len(set(ids))
    for host in ("diode.zone", "framatube.org", "tilvids.com", "peertube.tv", "conftube.com", "bitchute.com", "odysee.com",
                 "rumble.com", "d.tube", "9gag.com", "imgur.com", "www.failarmy.com", "www.afv.com",
                 "www.ebaumsworld.com", "cheezburger.com", "www.thedodo.com", "giphy.com", "tenor.com", "vimeo.com",
                 "www.dailymotion.com", "www.pexels.com", "pixabay.com", "coverr.co", "mixkit.co", "www.videvo.net"):
        assert site_for_host(host) is not None, host
    assert len(PEERTUBE_INSTANCES) == 5 and SITES_BY_ID["peertube"].host == "diode.zone"


def test_dtube_cards_collect_title_picture_and_duration():
    html = """<a href="https://d.tube/watch/9vvrSmTp9wL4BHiVUDZ5xe?c=music"><img src="https://nas1.d.tube/thumbnails/a.jpg"> 1:16</a>
      <a href="https://d.tube/watch/9vvrSmTp9wL4BHiVUDZ5xe?c=music">Деревенский Дурачок - Однажды во дворе</a>
      <a href="https://d.tube/d/music">Music Tube</a><a href="/latest">Latest</a>"""
    items = DTubeSite()._cards(html)
    assert len(items) == 1
    e = items[0]
    assert e.video_id == "watch/9vvrSmTp9wL4BHiVUDZ5xe" and e.title.startswith("Деревенский")
    assert e.duration_text == "1:16" and e.thumbnail == "https://nas1.d.tube/thumbnails/a.jpg"
    assert e.page_url == "https://d.tube/watch/9vvrSmTp9wL4BHiVUDZ5xe"
    assert DTubeSite().video_id_from_url("https://d.tube/watch/9vvrSmTp9wL4BHiVUDZ5xe?c=x") == "watch/9vvrSmTp9wL4BHiVUDZ5xe"


def test_dtube_falls_back_to_its_own_page():
    class Fake(DTubeSite):
        def page_url(self, vid):
            return "https://d.tube/" + vid
    import app.scraping.sites_more as m
    original = m.fetch_text
    m.fetch_text = lambda *a, **k: "<html><body>player loads later</body></html>"
    try:
        info = Fake().resolve("watch/9vvrSmTp9wL4BHiVUDZ5xe")
    finally:
        m.fetch_text = original
    assert info.urls == [] and info.embed_url == "https://d.tube/watch/9vvrSmTp9wL4BHiVUDZ5xe"


def test_sniff_page_finds_files_players_and_youtube():
    page = """<meta property="og:video" content="https://cdn.example/clip-720.mp4">
      <video><source src="/v/clip.webm"></video>
      <script type="application/ld+json">{"@type":"VideoObject","contentUrl":"https://cdn.example/clip.m3u8"}</script>
      <iframe src="https://player.vimeo.com/video/12345678"></iframe>"""
    urls, embed, youtube = sniff_page(page, "https://site.example/p/")
    assert urls == ["https://cdn.example/clip-720.mp4", "https://site.example/v/clip.webm", "https://cdn.example/clip.m3u8"]
    assert embed == "https://player.vimeo.com/video/12345678" and youtube is False
    urls, embed, youtube = sniff_page('<iframe src="https://www.youtube.com/embed/abc"></iframe>', "https://x.example/")
    assert (urls, embed, youtube) == ([], None, True)


def test_generic_site_gives_readable_errors():
    import app.scraping.sites_more as m
    original = m.fetch_text
    try:
        m.fetch_text = lambda *a, **k: '<iframe src="https://www.youtube.com/embed/abc"></iframe>'
        try:
            EbaumsworldSite().resolve("videos/funny-cat/1234")
        except SiteError as exc:
            assert "YouTube" in str(exc)
        else:
            raise AssertionError("expected SiteError")
        m.fetch_text = lambda *a, **k: "<p>nothing</p>"
        try:
            EbaumsworldSite().resolve("videos/funny-cat/1234")
        except SiteError as exc:
            assert "eBaum" in str(exc)
        else:
            raise AssertionError("expected SiteError")
    finally:
        m.fetch_text = original
    try:
        EbaumsworldSite().resolve("../etc/passwd")
    except SiteError:
        pass
    else:
        raise AssertionError("path tricks must be refused")


def test_ebaums_cards_skip_adult_titles():
    html = """<a href="/videos/funny-dog/111/"><h3>Funny dog</h3><img src="https://cdn.e/a.jpg"></a>
      <a href="/videos/adult-thing/222/"><h3>21 NSFW memes</h3></a><a href="/articles/x/3/">article</a>"""
    items = EbaumsworldSite()._cards(html)
    assert [e.video_id for e in items] == ["videos/funny-dog/111"]
    assert looks_adult("NSFW stuff") and not looks_adult("Sussex cat")


def test_failarmy_wordpress_posts():
    text = json.dumps([
        {"link": "https://www.failarmy.com/best-fails-of-the-week/", "title": {"rendered": "Best &amp; Funniest Fails"},
         "date": "2026-11-20T10:00:00", "yoast_head_json": {"og_image": [{"url": "https://i.fa/x.jpg"}]}},
        {"link": "https://other.example/x/", "title": {"rendered": "wrong host"}},
        {"link": "https://www.failarmy.com/sexy-thing/", "title": {"rendered": "sexy"}},
    ])
    items = parse_wp_posts(text, "failarmy", "FailArmy", "www.failarmy.com")
    assert len(items) == 1
    assert items[0].title == "Best & Funniest Fails" and items[0].published_date == "2026-11-20"
    assert items[0].page_url == "https://www.failarmy.com/best-fails-of-the-week/" and items[0].thumbnail == "https://i.fa/x.jpg"


def test_failarmy_reads_the_home_page_when_the_api_is_off():
    import app.scraping.sites_more as m
    calls = []
    original = m.fetch_text

    def fake(url, **k):
        calls.append(url)
        if "wp-json" in url:
            raise RuntimeError("blocked")
        return '<a href="/epic-fail-compilation/"><img src="https://i.fa/t.jpg">Epic fail compilation</a>'
    m.fetch_text = fake
    try:
        items = FailArmySite().latest(1, 5)
    finally:
        m.fetch_text = original
    assert len(calls) == 2 and items[0].video_id == "epic-fail-compilation"


def test_9gag_keeps_safe_animated_posts_only():
    text = json.dumps({"data": {"posts": [
        {"id": "aAbCd12", "type": "Animated", "title": "Cat falls", "nsfw": 0, "creationTs": 1760000000,
         "images": {"image460": {"url": "https://img/a.webp"}, "image460sv": {"url": "https://img/a_460sv.mp4", "duration": 7}}},
        {"id": "bBbCd12", "type": "Photo", "title": "pic", "images": {}},
        {"id": "cBbCd12", "type": "Animated", "title": "x", "nsfw": 1, "images": {"image460sv": {"url": "https://img/c.mp4"}}},
    ]}})
    items = parse_9gag(text)
    assert len(items) == 1 and items[0].duration_text == "0:07" and items[0].page_url == "https://9gag.com/gag/aAbCd12"
    assert NineGagSite().video_id_from_url("https://9gag.com/gag/aAbCd12") == "aAbCd12"


def test_bitchute_search_answer():
    text = json.dumps({"videos": [
        {"video_id": "lIo6FB4B-BY", "video_name": "Nice video", "thumbnail_url": "https://bcfiles/t.jpg", "duration": "3:21",
         "channel": {"channel_name": "Chan"}, "date_published": "2026-11-01T00:00:00Z"},
        {"video_id": "x", "video_name": "bad id"}]})
    items = parse_bitchute(text)
    assert len(items) == 1 and items[0].uploader == "Chan" and items[0].duration_seconds == 201
    site = BitChuteSite()
    assert site.video_id_from_url("https://www.bitchute.com/video/lIo6FB4B-BY/") == "lIo6FB4B-BY"
    info = site.resolve("lIo6FB4B-BY")
    assert info.urls == [] and info.embed_url == "https://www.bitchute.com/embed/lIo6FB4B-BY/" and site.prefer_ytdlp


def _with_pages(pages, run):
    """Runs ``run()`` while ``fetch_text`` answers from ``pages`` (a dict url -> html) instead of the internet."""
    real = sites_more.fetch_text

    def fake(url, **kwargs):
        if url not in pages:
            raise AssertionError(f"unexpected address {url}")
        return pages[url]

    sites_more.fetch_text = fake
    try:
        return run()
    finally:
        sites_more.fetch_text = real


def test_giphy_pages_need_no_key():
    html = ('<a href="/gifs/happy-dance-abc123XYZ"><img alt="happy dance GIF" src="x.gif"></a>'
            '<a href="/gifs/funny-reaction">a category</a><a href="/explore/cats">cats</a>'
            '<img src="https://media2.giphy.com/media/v1.Y2lk/Qw9ErTy12uIoP/giphy.webp">')
    items = parse_giphy_page(html)
    assert [e.video_id for e in items] == ["abc123XYZ", "Qw9ErTy12uIoP"]
    assert items[0].title == "Happy dance" and items[0].thumbnail == "https://media.giphy.com/media/abc123XYZ/200_s.gif"
    assert items[0].page_url == "https://giphy.com/gifs/abc123XYZ"
    site = GiphySite()
    assert site.video_id_from_url("https://giphy.com/gifs/happy-dance-abc123XYZ") == "abc123XYZ"
    assert site.video_id_from_url("https://media.giphy.com/media/abc123XYZ/giphy.mp4") == "abc123XYZ"
    assert site.resolve("abc123XYZ").urls[0] == "https://media.giphy.com/media/abc123XYZ/giphy.mp4"
    found = _with_pages({"https://giphy.com/search/happy-dance": html}, lambda: site.search("Happy dance!"))
    assert len(found) == 2


def test_tenor_pages_need_no_key():
    html = ('<a href="/view/dance-gif-12345678901"><img src="https://media.tenor.com/a/dance.gif" alt="Dance"></a>'
            '<a href="/en-GB/view/wave-gif-99887766"><img data-src="https://media.tenor.com/b/w.gif"></a><a href="/about">about</a>')
    items = parse_tenor_page(html)
    assert [e.video_id for e in items] == ["dance-gif-12345678901", "wave-gif-99887766"]
    assert items[0].title == "Dance" and items[0].thumbnail == "https://media.tenor.com/a/dance.gif"
    assert items[1].thumbnail == "https://media.tenor.com/b/w.gif"
    assert items[0].page_url == "https://tenor.com/view/dance-gif-12345678901"
    site = TenorSite()
    assert site.video_id_from_url("https://tenor.com/view/dance-gif-12345678901") == "dance-gif-12345678901"
    page = ('<meta property="og:video" content="https://media.tenor.com/a/dance.mp4">'
            '<video><source src="https://elsewhere.example/other.mp4"></video>')
    info = _with_pages({"https://tenor.com/view/dance-gif-12345678901": page}, lambda: site.resolve("dance-gif-12345678901"))
    assert info.urls == ["https://media.tenor.com/a/dance.mp4"]      # files from other hosts on the page are ignored
    try:
        site.resolve("../etc")
        assert False, "must refuse"
    except SiteError:
        pass


def test_imgur_pages_keep_only_certain_videos():
    html = ('<a href="/gallery/funny-clip-aB3dE9f"><video src="x.mp4"></video></a>'
            '<a href="/gallery/just-picture-zZ99Y8x"><img src="p.jpg"></a>'
            '<img src="https://i.imgur.com/Vid12XY.gifv">')
    items = parse_imgur_page(html)
    assert [e.video_id for e in items] == ["aB3dE9f", "Vid12XY"]
    assert items[0].title == "Funny clip" and items[0].page_url == "https://imgur.com/gallery/aB3dE9f"
    site = ImgurSite()
    assert site.video_id_from_url("https://i.imgur.com/Vid12XY.mp4") == "Vid12XY"
    page = '<meta property="og:video:secure_url" content="https://i.imgur.com/aB3dE9f.mp4">'
    info = _with_pages({"https://imgur.com/gallery/aB3dE9f": page}, lambda: site.resolve("aB3dE9f"))
    assert info.urls == ["https://i.imgur.com/aB3dE9f.mp4"]
    # the page cannot be read (robots.txt, blocked ...): Imgur's usual file address is still offered
    real = sites_more.fetch_text
    sites_more.fetch_text = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("blocked"))
    try:
        assert site.resolve("Vid12XY").urls == ["https://i.imgur.com/Vid12XY.mp4"]
    finally:
        sites_more.fetch_text = real


def test_coverr_pages_need_no_key():
    html = '<a href="/videos/sunset-over-sea-AbC123xy"><img src="https://c.example/t.jpg">Sunset over the sea</a><a href="/pricing">Pricing</a>'
    items = CoverrSite()._cards(html)
    assert len(items) == 1 and items[0].page_url == "https://coverr.co/videos/sunset-over-sea-AbC123xy"
    assert items[0].video_id == "videos/sunset-over-sea-AbC123xy" and items[0].thumbnail == "https://c.example/t.jpg"
    site = CoverrSite()
    assert site.video_id_from_url("https://coverr.co/videos/sunset-over-sea-AbC123xy") == "videos/sunset-over-sea-AbC123xy"
    page = '<video><source src="https://storage.coverr.co/videos/AbC123xy.mp4"></video>'
    info = _with_pages({"https://coverr.co/videos/sunset-over-sea-AbC123xy": page}, lambda: site.resolve("videos/sunset-over-sea-AbC123xy"))
    assert info.urls == ["https://storage.coverr.co/videos/AbC123xy.mp4"]


def test_no_site_needs_a_key_and_reddit_is_not_there():
    for name in ("GIPHY_API_KEY", "TENOR_API_KEY", "IMGUR_CLIENT_ID", "REDDIT_CLIENT_ID", "REDDIT_CLIENT_SECRET",
                 "COVERR_API_KEY", "ENABLE_SITES"):
        os.environ.pop(name, None)
    for source_id in ("giphy", "tenor", "imgur", "coverr"):
        assert SITES_BY_ID[source_id].enabled() and SITES_BY_ID[source_id].disabled_reason() is None
    assert "reddit" not in SITES_BY_ID      # its robots.txt forbids every automatic reader
    assert not SITES_BY_ID["afv"].enabled() and "ENABLE_SITES" in SITES_BY_ID["afv"].disabled_reason()
    os.environ["ENABLE_SITES"] = "afv, thedodo"
    assert SITES_BY_ID["afv"].enabled() and SITES_BY_ID["thedodo"].enabled() and not SITES_BY_ID["cheezburger"].enabled()
    os.environ.pop("ENABLE_SITES")
    assert SITES_BY_ID["dtube"].enabled() and SITES_BY_ID["bitchute"].enabled()


def test_scrape_skips_waiting_sites_and_spares_small_quotas():
    os.environ.pop("ENABLE_SITES", None)

    class Waiting(AfvSite):             # off by default: must not be asked
        def latest(self, page=1, limit=20):
            raise AssertionError("must not be asked while it is switched off")

    class Quota(DTubeSite):
        scrape_every = 3
        calls = 0

        def latest(self, page=1, limit=20):
            Quota.calls += 1
            return []

    store = Store(":memory:")
    summary = scrape_all(store, [Waiting(), Quota()], run=1)
    assert summary == {} and Quota.calls == 0          # run 1: Quota is not due, Waiting is off
    scrape_all(store, [Quota()], run=3)
    assert Quota.calls == 1                            # run 3 is due (1 page: DTube cannot page)
    assert due(Quota(), 0) and not due(Quota(), 2)
    assert pages_for(DTubeSite(), 4) == [1] and pages_for(VidevoSite(), 1) == [3, 4]
    assert search_live([Waiting()], "x", 1) == ([], [])


def test_peertube_instances_keep_their_own_ids():
    from app.scraping.sites import parse_peertube
    listing = '{"data":[{"uuid":"6a1d7d3c-1111-4222-8333-444455556666","name":"Hi","duration":5,"thumbnailPath":"/t.jpg"}]}'
    e = parse_peertube(listing, "framatube.org", "framatube", "Framatube")[0]
    assert (e.source_id, e.source_name) == ("framatube", "Framatube")
    assert e.page_url == "https://framatube.org/w/6a1d7d3c-1111-4222-8333-444455556666"
    fr = SITES_BY_ID["framatube"]
    assert fr.video_id_from_url("https://framatube.org/w/6a1d7d3c-1111-4222-8333-444455556666") == "6a1d7d3c-1111-4222-8333-444455556666"
    assert fr.video_id_from_url("https://tilvids.com/w/6a1d7d3c-1111-4222-8333-444455556666") is None
