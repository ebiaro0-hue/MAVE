from app.scraping.models import format_duration
from app.scraping.sites import (
    DailymotionSite, SiteError, extract_mixkit_mp4, extract_pexels_mp4, extract_pixabay_mp4, default_topic,
    parse_dailymotion, parse_mixkit, parse_odysee_resolve, parse_peertube, parse_pexels_page, parse_pixabay_page,
    parse_rumble, parse_vimeo_ids, parse_vimeo_oembed, parse_wikimedia, peertube_stream_urls, rumble_mp4_urls,
    odysee_stream_url, slugify, title_from_slug, site_for_host, SITES_BY_ID, ALL_SITES, PeerTubeSite, WikimediaSite,
    RumbleSite, OdyseeSite, VimeoSite, PexelsSite, MixkitSite,
)


def test_duration_and_slug_helpers():
    assert format_duration(125) == "2:05"
    assert format_duration(3725) == "1:02:05"
    assert format_duration(0) is None and format_duration(None) is None
    assert slugify("Nature & Sea!") == "nature-sea"
    assert title_from_slug("sea-waves-on-a-beach-1234") == "Sea waves on a beach"
    assert default_topic(1) == "nature" and default_topic(11) == "nature"


def test_peertube_list_and_streams():
    listing = """{"data":[{"uuid":"6a1d7d3c-1111-4222-8333-444455556666","name":"Hello","duration":125,
        "thumbnailPath":"/lazy-static/thumbnails/x.jpg","url":"https://diode.zone/videos/watch/6a1d7d3c-1111-4222-8333-444455556666",
        "publishedAt":"2025-03-04T10:00:00.000Z","channel":{"displayName":"Chan"},"account":{"displayName":"Acc"}},
        {"uuid":"bad","name":"skip"},{"uuid":"6a1d7d3c-1111-4222-8333-444455557777","name":"Live","isLive":true}]}"""
    items = parse_peertube(listing, "diode.zone")
    assert len(items) == 1
    e = items[0]
    assert (e.uploader, e.duration_text, e.published_date) == ("Chan", "2:05", "2025-03-04")
    assert e.thumbnail == "https://diode.zone/lazy-static/thumbnails/x.jpg"
    video = """{"files":[{"fileUrl":"https://h/1080.mp4","resolution":{"id":1080}},{"fileUrl":"https://h/480.mp4","resolution":{"id":480}},
        {"fileUrl":"https://h/720.mp4","resolution":{"id":720}}],"streamingPlaylists":[{"playlistUrl":"https://h/master.m3u8"}]}"""
    assert peertube_stream_urls(video) == ["https://h/720.mp4", "https://h/480.mp4", "https://h/1080.mp4", "https://h/master.m3u8"]


def test_wikimedia_keeps_only_playable_video():
    text = """{"query":{"pages":{"1":{"title":"File:Sea_waves.webm","index":2,"imageinfo":[{"url":"https://upload.wikimedia.org/a.webm",
        "thumburl":"https://upload.wikimedia.org/t.jpg","mime":"video/webm","extmetadata":{"Artist":{"value":"<a href='x'>Jane</a>"}}}]},
        "2":{"title":"File:Old.ogv","index":1,"imageinfo":[{"url":"https://upload.wikimedia.org/o.ogv","mime":"video/ogg"}]}}}}"""
    items = parse_wikimedia(text)
    assert len(items) == 1
    assert items[0].title == "Sea waves" and items[0].uploader == "Jane"
    assert items[0].video_id == "File:Sea_waves.webm"
    assert items[0].page_url == "https://commons.wikimedia.org/wiki/File:Sea_waves.webm"
    assert WikimediaSite().video_id_from_url("https://commons.wikimedia.org/wiki/File:Sea_waves.webm") == "File:Sea waves.webm"


def test_mixkit_listing_and_item_page():
    html = """<div><a href="/free-stock-video/sea-waves-on-a-beach-1234/"><img src="https://assets.mixkit.co/t.jpg"></a>
        <a href="/free-stock-video/sea-waves-on-a-beach-1234/">again</a><a href="/free-stock-video/nature/">tag</a></div>"""
    items = parse_mixkit(html)
    assert len(items) == 1
    assert items[0].video_id == "sea-waves-on-a-beach-1234"
    assert items[0].title == "Sea waves on a beach"
    assert items[0].thumbnail == "https://assets.mixkit.co/t.jpg"
    page = """<video src="https://assets.mixkit.co/videos/1234/1234-360.mp4"></video>
        <a href="https://assets.mixkit.co/videos/1234/1234-720.mp4">dl</a>"""
    assert extract_mixkit_mp4(page)[0] == "https://assets.mixkit.co/videos/1234/1234-720.mp4"
    assert MixkitSite().video_id_from_url("https://mixkit.co/free-stock-video/sea-waves-on-a-beach-1234/") == "sea-waves-on-a-beach-1234"


def test_rumble_listing_and_embed_json():
    html = """<ul><li class="video-listing-entry"><a class="videostream__link" href="/v6abc12-funny-cats.html">
        <img class="thumbnail__image" src="https://sp.rmbl.ws/t.jpg"></a><h3 class="thumbnail__title">Funny cats</h3>
        <span class="videostream__badge">3:21</span><address><div class="ellipsis-1">CatChannel</div></address></li></ul>"""
    items = parse_rumble(html)
    assert len(items) == 1
    e = items[0]
    assert (e.video_id, e.title, e.duration_text, e.duration_seconds, e.uploader) == ("v6abc12-funny-cats", "Funny cats", "3:21", 201, "CatChannel")
    assert RumbleSite().video_id_from_url("https://rumble.com/v6abc12-funny-cats.html") == "v6abc12-funny-cats"
    j = """{"ua":{"mp4":{"360":{"url":"https://r/360.mp4"},"720":{"url":"https://r/720.mp4"}}}}"""
    assert rumble_mp4_urls(j) == ["https://r/720.mp4", "https://r/360.mp4"]
    assert rumble_mp4_urls('{"u":{}}') == []


def test_odysee_dailymotion_vimeo():
    claim = "a" * 40
    resolved = ('{"result":{"lbry://vid#%s":{"claim_id":"%s","name":"vid","value":{"title":"My video",'
                '"thumbnail":{"url":"https://t/x.jpg"},"video":{"duration":61}},"signing_channel":{"name":"@chan","value":{"title":"Chan"}}}}}'
                % (claim, claim))
    o = parse_odysee_resolve(resolved)[0]
    assert (o.video_id, o.duration_text, o.uploader) == (claim + ":vid", "1:01", "Chan")
    assert o.page_url == "https://odysee.com/vid:aaaaaa"
    assert odysee_stream_url("vid", claim, "abcdef123") == f"https://player.odycdn.com/api/v3/streams/free/vid/{claim}/abcdef.mp4"
    d = parse_dailymotion('{"list":[{"id":"x8abc12","title":"T","owner.screenname":"Owner","thumbnail_360_url":"https://d/t.jpg","duration":90,"created_time":1700000000}]}')[0]
    assert (d.uploader, d.page_url, d.published_date) == ("Owner", "https://www.dailymotion.com/video/x8abc12", "2023-11-14")
    assert DailymotionSite().video_id_from_url("https://www.dailymotion.com/video/x8abc12") == "x8abc12"
    assert DailymotionSite().resolve("x8abc12").embed_url == "https://www.dailymotion.com/embed/video/x8abc12?autoplay=1"
    assert DailymotionSite().resolve("x8abc12").urls == []
    assert VimeoSite().resolve("123456").embed_url == "https://player.vimeo.com/video/123456?autoplay=1"


def test_keyless_pexels_pixabay_vimeo_readers():
    html = """<a href="/video/learning-solar-system-7605272/"><img src="https://images.pexels.com/videos/7605272/x.jpeg"></a>
        <a href="/video/learning-solar-system-7605272/">dup</a><a href="/search/videos/space/">tag</a>"""
    pi = parse_pexels_page(html)
    assert len(pi) == 1 and pi[0].video_id == "learning-solar-system-7605272" and pi[0].title == "Learning solar system"
    page = """{"src":"https:\\/\\/videos.pexels.com\\/video-files\\/7605272\\/7605272-uhd_2560_1440_30fps.mp4"}
        <source src="https://videos.pexels.com/video-files/7605272/7605272-hd_1280_720_30fps.mp4">"""
    assert extract_pexels_mp4(page)[0] == "https://videos.pexels.com/video-files/7605272/7605272-hd_1280_720_30fps.mp4"
    assert PexelsSite().video_id_from_url("https://www.pexels.com/video/learning-solar-system-7605272/") == "learning-solar-system-7605272"
    px = parse_pixabay_page('<a href="/videos/sea-waves-12345/"><img data-src="https://cdn.pixabay.com/t.jpg"></a>')
    assert px[0].title == "Sea waves" and px[0].thumbnail == "https://cdn.pixabay.com/t.jpg"
    pix = '"https://cdn.pixabay.com/video/2021/04/23/1-large.mp4" "https://cdn.pixabay.com/video/2021/04/23/1-medium.mp4" '
    assert extract_pixabay_mp4(pix)[0].endswith("1-medium.mp4")
    assert parse_vimeo_ids('<a href="/123456789">a</a><a href="https://vimeo.com/channels/staffpicks/7654321">b</a><a href="/about">c</a>') == ["123456789", "7654321"]
    v = parse_vimeo_oembed('{"title":"Film","author_name":"Dir","thumbnail_url":"https://i.vimeocdn.com/x.jpg","duration":75}', "123456789")
    assert v.duration_text == "1:15"
    assert parse_vimeo_oembed('{"title":""}', "1") is None


def test_every_site_has_a_unique_id_and_hosts():
    ids = [s.source_id for s in ALL_SITES]
    assert len(ids) == len(set(ids)) == 56          # 26 video sites (steps 1-15) + 30 news sites (step 16)
    assert all(s.hosts for s in ALL_SITES)
    assert site_for_host("rumble.com").source_id == "rumble"
    assert site_for_host("example.org") is None
    assert SITES_BY_ID["odysee"].topic_based and not SITES_BY_ID["peertube"].topic_based


def test_wrong_site_address_gives_a_readable_error():
    try:
        RumbleSite().resolve_url("https://rumble.com/about")
    except SiteError as exc:
        assert "Rumble" in str(exc)
        return
    raise AssertionError("expected SiteError")


def test_odysee_address_is_understood():
    claim = "b" * 40
    calls = []

    class Fake(OdyseeSite):
        def _resolve_claims(self, urls):
            calls.append(urls)
            return ('{"result":{"%s":{"claim_id":"%s","name":"my-vid","value":{"source":{"sd_hash":"abcdef999"}}}}}' % (urls[0], claim))

    info = Fake().resolve_url("https://odysee.com/@chan:1/my-vid:bbbbbb")
    assert calls == [["lbry://my-vid#bbbbbb"]]
    assert info.urls == [f"https://player.odycdn.com/api/v3/streams/free/my-vid/{claim}/abcdef.mp4"]
    assert info.embed_url == f"https://odysee.com/$/embed/my-vid/{claim}"
