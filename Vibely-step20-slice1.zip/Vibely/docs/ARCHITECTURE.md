# Vibely architecture and Step 20 status

## Component boundaries (as they exist today)

| Part | Language | Job | Status |
| --- | --- | --- | --- |
| Android app (`app/`) | Kotlin | UI, player, library, downloads (Android DownloadManager), settings | exists |
| Source adapters and server (`backend/`) | Python | HTML / RSS / API parsing, catalogue, `/api/*` | exists |
| Scraping coordinator | Go | bounded concurrent scheduling, source health | **not started** |
| Media / download core | Rust | streaming file pipeline, integrity checks, metadata | **not started** |

Deployment model: unchanged. The phone can read sites alone, or use the optional Render server. No new server
requirement was added.

## Done in Step 20 (slice 1)

* **Source capability matrix** (`backend/app/capabilities.py`, `docs/SOURCE_CAPABILITIES.md`): per site, how it plays,
  whether download is allowed and why, formats, always-present metadata. Audio-only export is reported as
  *not implemented* for every site. Exposed in `GET /api/sources`.
* **Download only where permitted**: the Download button now appears only for sites with a free reuse licence
  (`DownloadPolicy.kt`: Pexels, Pixabay, Mixkit, Coverr, Wikimedia Commons, NASA), and `DownloadsRepository.start`
  refuses the rest. Downloads already saved are untouched. Edit the list in both files to change the policy.

## Tested, and not tested

* Python: `backend/tests/test_capabilities.py` (10 tests) was run and passes. The older backend tests were **not**
  re-run here (pytest, httpx and fastapi were not installable offline).
* Kotlin: `DownloadPolicyTest.kt` and the two edits in `PlayerScreen.kt` / `DownloadsRepository.kt` were **not compiled
  or run** (no Android SDK / Gradle here). The GitHub **Vibely Android APK** workflow will compile them.

## Not done yet (nothing below exists in the code)

Go coordinator, Rust core and its Kotlin bridge, Python-to-Go interface, audio-only download and offline audio library,
queue pause/resume and persistence beyond Android DownloadManager, Data Saver / Wi-Fi-only / concurrency settings,
recommendations, search suggestions and history, playback speed / resume / autoplay settings, benchmarks, release
polish, ads. Go and Rust need a toolchain to compile and test them; they should be written only where they can be built.
