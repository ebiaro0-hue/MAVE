package com.vibely.app.data

import android.content.Context

/**
 * The two ways Vibely gets its videos:
 *  - **the phone** reads the websites itself (the original way, needs no server), and
 *  - **the Vibely server** (Render) reads them for you and keeps up with website changes.
 * [AUTO] uses the server when it answers and quietly falls back to the phone when it does not.
 */
enum class ContentMode(val key: String, val label: String, val description: String) {
    AUTO(
        "auto", "Automatic (recommended)",
        "Uses the Vibely server when it answers. If it is missing, asleep or failing, this phone reads the sites itself."
    ),
    PHONE(
        "phone", "This phone only",
        "Never uses the server. The phone reads the sites itself, exactly as before. Works with no server at all."
    ),
    SERVER(
        "server", "Server only",
        "Only uses the Vibely server. Shows an error when the server is down (good for testing the server)."
    );

    companion object {
        fun fromKey(key: String?): ContentMode = values().firstOrNull { it.key == key } ?: AUTO
    }
}

/**
 * Remembers that the server did not answer, so the next few requests go straight to the phone instead of each
 * waiting for a timeout. A free server that sleeps is woken by [VibelyRepository.warmUp], which [reset]s this.
 */
class BackendBreaker(
    private val pauseMs: Long = 3 * 60_000L,
    private val clock: () -> Long = System::currentTimeMillis
) {
    @Volatile
    private var downUntil = 0L

    fun available(): Boolean = clock() >= downUntil
    fun trip() {
        downUntil = clock() + pauseMs
    }

    fun reset() {
        downUntil = 0L
    }
}

/** The chosen [ContentMode], kept on the device. */
object ContentPrefs {
    private const val FILE = "content"
    private const val KEY_MODE = "mode"

    fun mode(context: Context): ContentMode =
        ContentMode.fromKey(context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_MODE, null))

    fun setMode(context: Context, mode: ContentMode) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_MODE, mode.key).apply()
    }
}
