package com.vibely.app

import android.content.Context
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/*
 * Shared by the main player (PlaybackService) and the Shorts player, so both open video files the same way.
 *
 * Why this exists: many video servers refuse a request that looks like "some app" (no browser name, no Referer) or
 * that follows a redirect from http to https. The player then shows an error, or plays picture without sound.
 * Here every request carries an ordinary mobile-browser name, follows redirects, waits a little longer, and sends
 * the Referer of the site the file belongs to.
 */

internal const val BROWSER_USER_AGENT =
    "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0.0.0 Mobile Safari/537.36"

// Host ending of a media file -> the page of the site that file belongs to.
private val REFERRERS = listOf(
    "rumble.com" to "https://rumble.com/",
    "1a-1791.com" to "https://rumble.com/",
    "rmbl.ws" to "https://rumble.com/",
    "9cache.com" to "https://9gag.com/",
    "9gag.com" to "https://9gag.com/",
    "giphy.com" to "https://giphy.com/",
    "tenor.com" to "https://tenor.com/",
    "imgur.com" to "https://imgur.com/",
    "coverr.co" to "https://coverr.co/",
    "pexels.com" to "https://www.pexels.com/",
    "pixabay.com" to "https://pixabay.com/",
    "mixkit.co" to "https://mixkit.co/",
    "videvo.net" to "https://www.videvo.net/",
    "bitchute.com" to "https://www.bitchute.com/",
    "ebaumsworld.com" to "https://www.ebaumsworld.com/",
    "failarmy.com" to "https://www.failarmy.com/",
    "odycdn.com" to "https://odysee.com/",
    "odysee.com" to "https://odysee.com/",
    "dailymotion.com" to "https://www.dailymotion.com/",
    "dmcdn.net" to "https://www.dailymotion.com/",
    "vimeocdn.com" to "https://player.vimeo.com/",
    "d.tube" to "https://d.tube/"
)

/** The Referer to send for a file on [host], or null when the site does not need one. */
internal fun referrerFor(host: String): String? {
    val h = host.lowercase()
    return REFERRERS.firstOrNull { (suffix, _) -> h == suffix || h.endsWith(".$suffix") }?.second
}

/**
 * A stream address that hides ".m3u8" in its query (or has no file ending) is not recognised as HLS by the player,
 * which then fails on a perfectly good stream. Say what it is. Returns null when the player can tell on its own.
 */
internal fun mimeHint(url: String): String? {
    val lower = url.lowercase()
    val path = lower.substringBefore('?')
    return if (!path.endsWith(".m3u8") && lower.contains(".m3u8")) MimeTypes.APPLICATION_M3U8 else null
}

@OptIn(UnstableApi::class)
internal fun vibelyMediaSourceFactory(context: Context): DefaultMediaSourceFactory {
    val http = DefaultHttpDataSource.Factory()
        .setUserAgent(BROWSER_USER_AGENT)
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15_000)
        .setReadTimeoutMs(20_000)
    val withReferrer = ResolvingDataSource.Factory(
        DefaultDataSource.Factory(context, http),
        ResolvingDataSource.Resolver { spec: DataSpec ->
            val referrer = referrerFor(spec.uri.host.orEmpty())
            if (referrer == null) spec else spec.withAdditionalHeaders(mapOf("Referer" to referrer))
        }
    )
    return DefaultMediaSourceFactory(withReferrer)
}

/** The one way Vibely builds a player: movie audio, audio focus, full volume, browser-like requests. */
@OptIn(UnstableApi::class)
internal fun buildVibelyPlayer(context: Context): ExoPlayer =
    ExoPlayer.Builder(context)
        .setMediaSourceFactory(vibelyMediaSourceFactory(context))
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            /* handleAudioFocus = */ true
        )
        .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
        .build()
        .apply { volume = 1f }

/** Does the clip that is loaded have sound the phone can play? */
internal enum class SoundState { UNKNOWN, OK, NONE, UNPLAYABLE }

internal fun Tracks.soundState(): SoundState {
    if (groups.isEmpty()) return SoundState.UNKNOWN          // nothing loaded yet
    val audio = groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    return when {
        audio.isEmpty() -> SoundState.NONE                    // the file has no audio track at all
        audio.any { it.isSupported } -> SoundState.OK
        else -> SoundState.UNPLAYABLE                         // it has sound, but this phone cannot decode it
    }
}

internal fun SoundState.message(): String? = when (this) {
    SoundState.NONE -> "No sound in this clip"
    SoundState.UNPLAYABLE -> "This phone can't play this clip's sound"
    else -> null
}

/** Small label on top of a video, so "silent clip" is not mistaken for "broken sound". */
@Composable
internal fun SoundBadge(state: SoundState, modifier: Modifier = Modifier) {
    val text = state.message() ?: return
    Text(
        text,
        color = Color.White,
        fontSize = 12.sp,
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
