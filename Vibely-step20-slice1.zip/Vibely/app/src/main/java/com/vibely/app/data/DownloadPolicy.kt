package com.vibely.app.data

/**
 * Which sites may be saved for offline use (Step 20).
 *
 * Only sites whose clips carry a free reuse licence are listed. For every other site Vibely plays the video
 * but shows no Download button, so nothing looks like it works when it must not.
 * Keep this list equal to `_DOWNLOAD_ALLOWED` in backend/app/capabilities.py (both are checked by tests).
 */
object DownloadPolicy {
    val allowedSourceIds: Set<String> = setOf("pexels", "pixabay", "mixkit", "coverr", "wikimedia", "nasa")

    fun allows(sourceId: String): Boolean = sourceId in allowedSourceIds

    /** Plain-language reason shown when a download is refused. */
    const val PLAYBACK_ONLY_MESSAGE =
        "This site's videos can be watched in Vibely but not downloaded: they belong to their uploaders."
}
