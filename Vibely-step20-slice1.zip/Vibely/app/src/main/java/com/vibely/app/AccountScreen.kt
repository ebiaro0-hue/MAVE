package com.vibely.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibely.app.data.Account
import com.vibely.app.data.CloudSync
import com.vibely.app.data.LibraryRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Sign in / create account / sync status. Works only when the build includes google-services.json. */
@Composable
fun AccountScreen(
    cloud: CloudSync,
    library: LibraryRepository,
    account: Account?,
    syncing: Boolean,
    syncStatus: String,
    onSyncNow: () -> Unit,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var confirmSignOut by remember { mutableStateOf(false) }
    var alsoClear by remember { mutableStateOf(false) }

    BackHandler(onBack = onClose)

    fun launchAction(action: suspend () -> Unit) {
        scope.launch {
            busy = true
            error = null
            info = null
            try {
                action()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Something went wrong."
            } finally {
                busy = false
            }
        }
    }

    fun validCredentials(): Boolean {
        val ok = email.contains("@") && password.length >= 6
        if (!ok) error = "Enter your email and a password of at least 6 characters."
        return ok
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }
            Text("Account", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp)) {
            when {
                !cloud.configured -> {
                    Text("Cloud sync isn't set up in this build", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Your history, likes, saved videos and playlists still work on this device. " +
                            "To sync them between devices, add your Firebase google-services.json and rebuild " +
                            "(see “Connect Firebase” in the README).",
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }

                account == null -> {
                    Text("Sign in to sync your library", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "History, liked videos, saved items and playlists follow you across your devices.",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(20.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Email") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = fieldColors()
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = fieldColors()
                    )
                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp)
                    }
                    info?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = Color(0xFF9CCC65), fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Button(
                        enabled = !busy,
                        onClick = { if (validCredentials()) launchAction { cloud.signIn(email, password) } },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) { Text(if (busy) "Please wait…" else "Sign in") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        enabled = !busy,
                        onClick = { if (validCredentials()) launchAction { cloud.signUp(email, password) } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Create account", color = Color.White) }
                    TextButton(
                        enabled = !busy,
                        onClick = {
                            if (!email.contains("@")) {
                                error = "Enter your email above first."
                            } else {
                                launchAction {
                                    cloud.resetPassword(email)
                                    info = "Password reset email sent. Check your inbox."
                                }
                            }
                        }
                    ) { Text("Forgot password?", color = Accent) }
                }

                else -> {
                    Text("Signed in", color = Color.Gray, fontSize = 12.sp)
                    Text(account.email ?: account.uid, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        enabled = !syncing,
                        onClick = onSyncNow,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) { Text(if (syncing) "Syncing…" else "Sync now") }
                    if (syncing) {
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
                    }
                    if (syncStatus.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(syncStatus, color = Color.LightGray, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Changes sync automatically while you're online. Items you remove while offline may come back on the next sync.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(24.dp))
                    OutlinedButton(
                        onClick = { confirmSignOut = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Sign out", color = Color.White) }
                }
            }
        }
    }

    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text("Sign out?") },
            text = {
                Column {
                    Text("Your library stays in your account and can be synced again when you sign back in.")
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = alsoClear, onCheckedChange = { alsoClear = it })
                        Text("Also remove my library from this device", fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmSignOut = false
                    scope.launch {
                        if (alsoClear) {
                            library.clearLocal()
                            cloud.setLastSyncedUid(null)
                        }
                        cloud.signOut()
                        alsoClear = false
                    }
                }) { Text("Sign out", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = Accent,
    unfocusedBorderColor = Color.DarkGray,
    focusedLabelColor = Accent,
    unfocusedLabelColor = Color.Gray,
    cursorColor = Accent
)
