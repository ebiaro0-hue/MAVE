package com.vibely.app.data

import com.vibely.app.MediaItem

/** Appends a freshly loaded page to the list, skipping items that are already shown. */
fun mergePage(existing: List<MediaItem>, incoming: List<MediaItem>): List<MediaItem> {
    val known = existing.mapTo(HashSet()) { it.key }
    return existing + incoming.filter { known.add(it.key) }
}
