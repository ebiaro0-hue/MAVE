package com.vibely.app.data

import android.content.Context
import android.util.Log
import com.vibely.app.MediaItem
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class Account(val uid: String, val email: String?)

data class CloudEntry(val item: MediaItem, val time: Long)

data class CloudPlaylist(
    val cloudId: String,
    val name: String,
    val createdAt: Long,
    val items: List<CloudEntry>
)

data class CloudSnapshot(
    val likes: List<CloudEntry>,
    val saved: List<CloudEntry>,
    val history: List<CloudEntry>,
    val playlists: List<CloudPlaylist>
)

private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
    addOnCanceledListener { cont.cancel() }
}

/**
 * Firebase Auth (email + password) and Firestore storage for the user's library.
 *
 * If the app was built without google-services.json, [configured] is false and every call is a safe no-op,
 * so the app keeps working fully offline on the device.
 *
 * Firestore layout (matches firebase/firestore.rules):
 *   users/{uid}/likes/{key}, saved/{key}, history/{key}
 *   users/{uid}/playlists/{cloudId}  and  .../playlists/{cloudId}/items/{key}
 * where {key} = "sourceId:id".
 */
class CloudSync(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val configured: Boolean = FirebaseApp.getApps(appContext).isNotEmpty()

    // ---------------- auth ----------------

    fun account(): Flow<Account?> {
        if (!configured) return flowOf<Account?>(null)
        return callbackFlow<Account?> {
            val auth = FirebaseAuth.getInstance()
            val listener = FirebaseAuth.AuthStateListener { a ->
                trySend(a.currentUser?.let { Account(it.uid, it.email) })
            }
            auth.addAuthStateListener(listener)
            awaitClose { auth.removeAuthStateListener(listener) }
        }
    }

    fun currentUid(): String? = if (configured) FirebaseAuth.getInstance().currentUser?.uid else null

    fun lastSyncedUid(): String? = prefs.getString("last_uid", null)
    fun setLastSyncedUid(uid: String?) = prefs.edit().putString("last_uid", uid).apply()

    suspend fun signIn(email: String, password: String) = authCall {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun signUp(email: String, password: String) = authCall {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun resetPassword(email: String) = authCall {
        FirebaseAuth.getInstance().sendPasswordResetEmail(email.trim()).await()
    }

    fun signOut() {
        if (configured) FirebaseAuth.getInstance().signOut()
    }

    private suspend fun authCall(block: suspend () -> Unit) {
        if (!configured) throw IllegalStateException("Cloud sync is not set up in this build.")
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            throw IllegalStateException(friendly(e))
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is FirebaseAuthWeakPasswordException -> "Password is too weak. Use at least 6 characters."
        is FirebaseAuthUserCollisionException -> "An account with this email already exists. Try signing in."
        is FirebaseAuthInvalidUserException -> "No account found for this email."
        is FirebaseAuthInvalidCredentialsException -> "Email or password is incorrect."
        is FirebaseNetworkException -> "No internet connection."
        else -> e.localizedMessage ?: "Something went wrong. Please try again."
    }

    // ---------------- write-through (fire and forget; Firestore queues these while offline) ----------------

    fun pushLike(item: MediaItem, time: Long) = put("likes", item.key, item.toMap(time))
    fun removeLike(item: MediaItem) = remove("likes", item.key)
    fun pushSaved(item: MediaItem, time: Long) = put("saved", item.key, item.toMap(time))
    fun removeSaved(item: MediaItem) = remove("saved", item.key)
    fun pushHistory(item: MediaItem, time: Long) = put("history", item.key, item.toMap(time))
    fun removeHistory(item: MediaItem) = remove("history", item.key)

    fun clearHistory() {
        val user = userDoc() ?: return
        scope.launch {
            try {
                user.collection("history").get().await().documents.forEach { it.reference.delete() }
            } catch (e: Exception) {
                Log.w(TAG, "clearHistory failed: ${e.message}")
            }
        }
    }

    fun pushPlaylist(cloudId: String, name: String, createdAt: Long): Task<Void>? =
        userDoc()?.collection("playlists")?.document(cloudId)
            ?.set(mapOf("name" to name, "createdAt" to createdAt))

    fun deletePlaylist(cloudId: String) {
        val user = userDoc() ?: return
        scope.launch {
            try {
                val playlist = user.collection("playlists").document(cloudId)
                playlist.collection("items").get().await().documents.forEach { it.reference.delete() }
                playlist.delete()
            } catch (e: Exception) {
                Log.w(TAG, "deletePlaylist failed: ${e.message}")
            }
        }
    }

    fun pushPlaylistItem(cloudId: String, item: MediaItem, time: Long): Task<Void>? =
        userDoc()?.collection("playlists")?.document(cloudId)
            ?.collection("items")?.document(item.key)?.set(item.toMap(time))

    fun removePlaylistItem(cloudId: String, item: MediaItem): Task<Void>? =
        userDoc()?.collection("playlists")?.document(cloudId)
            ?.collection("items")?.document(item.key)?.delete()

    /** Waits for a batch of pushed writes to be acknowledged by the server (used by "Sync now"). */
    suspend fun awaitAll(tasks: List<Task<Void>>) {
        if (tasks.isEmpty()) return
        withTimeout(30_000) { Tasks.whenAll(tasks).await() }
    }

    // ---------------- read ----------------

    /** Reads the signed-in user's cloud library from the server. Throws if offline or signed out. */
    suspend fun fetch(): CloudSnapshot {
        val user = userDoc() ?: throw IllegalStateException("Sign in first.")
        return withTimeout(30_000) {
            suspend fun entries(path: com.google.firebase.firestore.CollectionReference): List<CloudEntry> =
                path.get(Source.SERVER).await().documents.mapNotNull { d ->
                    d.toItem()?.let { CloudEntry(it, d.getLong("time") ?: 0L) }
                }

            val playlists = user.collection("playlists").get(Source.SERVER).await().documents.map { d ->
                CloudPlaylist(
                    cloudId = d.id,
                    name = d.getString("name") ?: "Playlist",
                    createdAt = d.getLong("createdAt") ?: 0L,
                    items = entries(d.reference.collection("items"))
                )
            }
            CloudSnapshot(
                likes = entries(user.collection("likes")),
                saved = entries(user.collection("saved")),
                history = entries(user.collection("history")),
                playlists = playlists
            )
        }
    }

    // ---------------- helpers ----------------

    private fun userDoc(): DocumentReference? {
        if (!configured) return null
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return null
        return FirebaseFirestore.getInstance().collection("users").document(uid)
    }

    private fun put(collection: String, id: String, data: Map<String, Any?>): Task<Void>? =
        userDoc()?.collection(collection)?.document(id)?.set(data)

    private fun remove(collection: String, id: String): Task<Void>? =
        userDoc()?.collection(collection)?.document(id)?.delete()

    private fun MediaItem.toMap(time: Long): Map<String, Any?> = mapOf(
        "sourceId" to sourceId,
        "id" to id,
        "title" to title,
        "uploader" to uploader,
        "thumbnailUrl" to thumbnailUrl,
        "duration" to duration,
        "source" to source,
        "mediaType" to mediaType,
        "pageUrl" to pageUrl,
        "mediaUrl" to mediaUrl,
        "time" to time
    )

    private fun DocumentSnapshot.toItem(): MediaItem? {
        val itemId = getString("id") ?: return null
        return MediaItem(
            id = itemId,
            title = getString("title") ?: "Untitled",
            uploader = getString("uploader") ?: "Unknown",
            thumbnailUrl = getString("thumbnailUrl"),
            duration = getString("duration") ?: "",
            source = getString("source") ?: "Unknown",
            sourceId = getString("sourceId") ?: "",
            mediaType = getString("mediaType"),
            pageUrl = getString("pageUrl"),
            mediaUrl = getString("mediaUrl")
        )
    }

    private companion object {
        const val TAG = "CloudSync"
    }
}
