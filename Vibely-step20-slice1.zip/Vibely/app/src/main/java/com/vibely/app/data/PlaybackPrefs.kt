package com.vibely.app.data

import android.content.Context

/** Small on-device playback settings. */
object PlaybackPrefs {
    private const val FILE = "playback"
    private const val KEY_BACKGROUND = "background_play"

    fun backgroundPlay(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_BACKGROUND, true)

    fun setBackgroundPlay(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_BACKGROUND, enabled).apply()
    }
}
