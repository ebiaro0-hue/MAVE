package com.vibely.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Plays a video from a site's own web player (Dailymotion, Vimeo, Rumble, Odysee, PeerTube) INSIDE the app.
 *
 * The page can only navigate within the player's own website; anything else is blocked, so the player can never
 * send the person to another site or to the browser. The player's fullscreen button works (landscape, Back exits).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun EmbedPlayer(url: String, modifier: Modifier = Modifier, onFailed: () -> Unit = {}) {
    // "player.vimeo.com" -> "vimeo.com": the player may use sub-domains of its own site, nothing else.
    val site = remember(url) { Uri.parse(url).host.orEmpty().split('.').takeLast(2).joinToString(".") }
    var fullscreenView by remember { mutableStateOf<View?>(null) }
    var hideFullscreen by remember { mutableStateOf<(() -> Unit)?>(null) }

    BackHandler(enabled = fullscreenView != null) { hideFullscreen?.invoke() }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            fun allowed(target: Uri?): Boolean {
                val h = target?.host.orEmpty()
                return h == site || h.endsWith(".$site")
            }

            WebView(context).apply {
                setBackgroundColor(AndroidColor.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                // Web players (Dailymotion, Vimeo, Rumble ...) refuse or start muted when they see an embedded "wv" browser
                // or cannot keep their cookies; look like an ordinary mobile browser and keep the player's cookies.
                settings.userAgentString = settings.userAgentString.replace("; wv", "")
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                        !allowed(request?.url)

                    @Deprecated("Used on Android 6 (API 23)")
                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean =
                        !allowed(url?.let { Uri.parse(it) })

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) onFailed()
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    private var callback: CustomViewCallback? = null

                    override fun onShowCustomView(view: View?, cb: CustomViewCallback?) {
                        val activity = context.findActivity()
                        if (view == null || activity == null) {
                            cb?.onCustomViewHidden()
                            return
                        }
                        (activity.window.decorView as ViewGroup).addView(
                            view,
                            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        )
                        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        callback = cb
                        fullscreenView = view
                        hideFullscreen = { onHideCustomView() }
                    }

                    override fun onHideCustomView() {
                        val view = fullscreenView ?: return
                        val activity = context.findActivity()
                        (view.parent as? ViewGroup)?.removeView(view)
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        callback?.onCustomViewHidden()
                        callback = null
                        fullscreenView = null
                        hideFullscreen = null
                    }
                }

                loadUrl(url)
            }
        },
        onRelease = { webView ->
            hideFullscreen?.invoke()
            webView.stopLoading()
            webView.loadUrl("about:blank") // stops sound at once
            webView.destroy()
        }
    )
}
