package com.vibely.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TtlCacheTest {
    @Test
    fun returnsFreshValue() {
        var now = 0L
        val cache = TtlCache<String, Int>(maxEntries = 5, ttlMs = 1_000) { now }
        cache.put("a", 1)
        now = 1_000
        assertEquals(1, cache.get("a"))
    }

    @Test
    fun expiredValueIsHiddenButStaleStillReadable() {
        var now = 0L
        val cache = TtlCache<String, Int>(maxEntries = 5, ttlMs = 1_000) { now }
        cache.put("a", 1)
        now = 1_001
        assertNull(cache.get("a"))
        assertEquals(1, cache.getStale("a"))
    }

    @Test
    fun evictsLeastRecentlyUsed() {
        val cache = TtlCache<String, Int>(maxEntries = 2, ttlMs = 60_000) { 0L }
        cache.put("a", 1)
        cache.put("b", 2)
        assertEquals(1, cache.get("a")) // "a" becomes most recent
        cache.put("c", 3)               // evicts "b"
        assertNull(cache.getStale("b"))
        assertEquals(1, cache.get("a"))
        assertEquals(3, cache.get("c"))
    }

    @Test
    fun clearEmptiesTheCache() {
        val cache = TtlCache<String, Int>(maxEntries = 2, ttlMs = 60_000) { 0L }
        cache.put("a", 1)
        cache.clear()
        assertNull(cache.getStale("a"))
    }
}
