package com.vibely.app

import androidx.media3.common.MimeTypes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PlayerSupportTest {
    @Test
    fun refererMatchesTheSiteAndItsSubdomainsOnly() {
        assertEquals("https://rumble.com/", referrerFor("1a-1791.com"))
        assertEquals("https://rumble.com/", referrerFor("RUMBLE.com"))
        assertEquals("https://9gag.com/", referrerFor("img-9gag-fun.9cache.com"))
        assertEquals("https://www.pexels.com/", referrerFor("videos.pexels.com"))
        assertNull(referrerFor("example.org"))
        assertNull(referrerFor("notrumble.com"))
        assertNull(referrerFor(""))
    }

    @Test
    fun hlsIsNamedOnlyWhenTheAddressDoesNotSayItInThePath() {
        assertNull(mimeHint("https://x.example/a.m3u8?token=1"))
        assertNull(mimeHint("https://x.example/a.mp4"))
        assertEquals(MimeTypes.APPLICATION_M3U8, mimeHint("https://x.example/play?file=a.m3u8"))
    }
}
