package com.vibely.app.data

import com.vibely.app.MediaItem
import org.junit.Assert.assertEquals
import org.junit.Test

class PagingTest {
    private fun item(id: String, source: String = "ia") =
        MediaItem(id = id, title = "T$id", uploader = "U", sourceId = source)

    @Test
    fun appendsOnlyNewItemsInOrder() {
        val merged = mergePage(listOf(item("1"), item("2")), listOf(item("2"), item("3")))
        assertEquals(listOf("1", "2", "3"), merged.map { it.id })
    }

    @Test
    fun sameIdFromDifferentSourcesIsNotADuplicate() {
        val merged = mergePage(listOf(item("1", "ia")), listOf(item("1", "other")))
        assertEquals(2, merged.size)
    }

    @Test
    fun duplicatesInsideTheNewPageAreDropped() {
        val merged = mergePage(emptyList(), listOf(item("1"), item("1"), item("2")))
        assertEquals(listOf("1", "2"), merged.map { it.id })
    }
}
