package com.vibely.app

import org.junit.Assert.assertEquals
import org.junit.Test

class FormatBytesTest {
    @Test
    fun formatsSizesForPeople() {
        assertEquals("0 B", formatBytes(0))
        assertEquals("512 B", formatBytes(512))
        assertEquals("1.5 KB", formatBytes(1536))
        assertEquals("50.0 MB", formatBytes(52_428_800))
        assertEquals("150 MB", formatBytes(150L * 1024 * 1024))
    }
}
