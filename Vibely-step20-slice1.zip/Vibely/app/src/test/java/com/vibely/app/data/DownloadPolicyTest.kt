package com.vibely.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadPolicyTest {
    @Test
    fun freeLicenceSitesAreAllowed() {
        listOf("pexels", "pixabay", "mixkit", "coverr", "wikimedia", "nasa").forEach {
            assertTrue(it, DownloadPolicy.allows(it))
        }
    }

    @Test
    fun otherSitesAreNotAllowed() {
        listOf("rumble", "vimeo", "dailymotion", "ted", "giphy", "bitchute", "", "unknown").forEach {
            assertFalse(it, DownloadPolicy.allows(it))
        }
    }

    @Test
    fun sameIdsAsTheServer() {
        // Mirrors backend/app/capabilities.py; test_capabilities.py checks the same six ids.
        assertEquals(
            setOf("pexels", "pixabay", "mixkit", "coverr", "wikimedia", "nasa"),
            DownloadPolicy.allowedSourceIds
        )
    }
}
