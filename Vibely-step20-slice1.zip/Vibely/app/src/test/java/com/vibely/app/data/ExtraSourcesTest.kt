package com.vibely.app.data

import com.vibely.app.MediaItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExtraSourcesTest {
    private fun fake(source: String, id: String) = MediaItem(id = id, title = id, uploader = "u", sourceId = source)

    @Test
    fun robotsRulesAreHonoured() {
        val txt = "User-agent: *\nDisallow: /private\nAllow: /private/open\nDisallow: /*.json$\n\nUser-agent: other\nDisallow: /"
        assertTrue(robotsAllows(txt, "/free-stock-video/"))
        assertFalse(robotsAllows(txt, "/private/area"))
        assertTrue(robotsAllows(txt, "/private/open/page"))
        assertFalse(robotsAllows(txt, "/data/list.json"))
        assertTrue(robotsAllows("", "/anything"))
    }

    @Test
    fun interleaveAndMixInKeepVarietyAndDropDuplicates() {
        val a = listOf(fake("a", "1"), fake("a", "2"), fake("a", "3"))
        val b = listOf(fake("b", "1"))
        assertEquals(listOf("a:1", "b:1", "a:2", "a:3"), interleave(listOf(a, b)).map { it.key })
        val base = (1..6).map { fake("ia", "$it") }
        val mixed = mixIn(base, listOf(fake("x", "1"), fake("x", "2"), fake("x", "3")), every = 3).map { it.key }
        assertEquals(listOf("ia:1", "ia:2", "ia:3", "x:1", "ia:4", "ia:5", "ia:6", "x:2", "x:3"), mixed)
        assertEquals(base, mixIn(base, emptyList()))
    }

    @Test
    fun peerTubeInstancesKeepTheirOwnIds() {
        val list = """{"data":[{"uuid":"6a1d7d3c-1111-4222-8333-444455556666","name":"Hi","duration":5,"thumbnailPath":"/t.jpg"}]}"""
        val item = parsePeerTube(list, "framatube.org", "framatube", "Framatube").single()
        assertEquals("framatube", item.sourceId)
        assertEquals("Framatube", item.source)
        assertEquals("https://framatube.org/w/6a1d7d3c-1111-4222-8333-444455556666", item.pageUrl)
        // the default still means the original diode.zone source, so saved libraries keep working
        assertEquals("peertube", parsePeerTube(list, "diode.zone").single().sourceId)
    }

    @Test
    fun peerTubeListAndStreams() {
        val list = """{"data":[{"uuid":"6a1d7d3c-1111-4222-8333-444455556666","name":"Hello","duration":125,
            "thumbnailPath":"/lazy-static/thumbnails/x.jpg","url":"https://diode.zone/videos/watch/6a1d7d3c-1111-4222-8333-444455556666",
            "channel":{"displayName":"Chan"},"account":{"displayName":"Acc"}},{"uuid":"bad","name":"skip"}]}"""
        val items = parsePeerTube(list, "diode.zone")
        assertEquals(1, items.size)
        assertEquals("Chan", items[0].uploader)
        assertEquals("2:05", items[0].duration)
        assertEquals("https://diode.zone/lazy-static/thumbnails/x.jpg", items[0].thumbnailUrl)
        val video = """{"files":[{"fileUrl":"https://h/1080.mp4","resolution":{"id":1080}},{"fileUrl":"https://h/480.mp4","resolution":{"id":480}},
            {"fileUrl":"https://h/720.mp4","resolution":{"id":720}}],"streamingPlaylists":[{"playlistUrl":"https://h/master.m3u8"}]}"""
        assertEquals(
            listOf("https://h/720.mp4", "https://h/480.mp4", "https://h/1080.mp4", "https://h/master.m3u8"),
            peerTubeStreamUrls(video)
        )
    }

    @Test
    fun wikimediaKeepsOnlyPlayableVideo() {
        val json = """{"query":{"pages":{"1":{"title":"File:Sea_waves.webm","index":2,"imageinfo":[{"url":"https://upload.wikimedia.org/a.webm",
            "thumburl":"https://upload.wikimedia.org/t.jpg","mime":"video/webm","extmetadata":{"Artist":{"value":"<a href='x'>Jane</a>"}}}]},
            "2":{"title":"File:Old.ogv","index":1,"imageinfo":[{"url":"https://upload.wikimedia.org/o.ogv","mime":"video/ogg"}]}}}}"""
        val items = parseWikimedia(json)
        assertEquals(1, items.size)
        assertEquals("Sea waves", items[0].title)
        assertEquals("Jane", items[0].uploader)
        assertEquals("https://upload.wikimedia.org/a.webm", items[0].mediaUrl)
    }

    @Test
    fun mixkitListingAndItemPage() {
        val html = """<div><a href="/free-stock-video/sea-waves-on-a-beach-1234/"><img src="https://assets.mixkit.co/t.jpg"></a>
            <a href="/free-stock-video/sea-waves-on-a-beach-1234/">again</a><a href="/free-stock-video/nature/">tag</a></div>"""
        val items = parseMixkit(html)
        assertEquals(1, items.size)
        assertEquals("sea-waves-on-a-beach-1234", items[0].id)
        assertEquals("Sea waves on a beach", items[0].title)
        val page = """<video src="https://assets.mixkit.co/videos/1234/1234-360.mp4"></video>
            <a href="https://assets.mixkit.co/videos/1234/1234-720.mp4">dl</a>"""
        assertEquals("https://assets.mixkit.co/videos/1234/1234-720.mp4", extractMixkitMp4(page).first())
        assertEquals("nature-sea", slugify("Nature & Sea!"))
    }

    @Test
    fun rumbleListingAndEmbedJson() {
        val html = """<ul><li class="video-listing-entry"><a class="videostream__link" href="/v6abc12-funny-cats.html">
            <img class="thumbnail__image" src="https://sp.rmbl.ws/t.jpg"></a><h3 class="thumbnail__title">Funny cats</h3>
            <span class="videostream__badge">3:21</span><address><div class="ellipsis-1">CatChannel</div></address></li></ul>"""
        val item = parseRumble(html).single()
        assertEquals("v6abc12-funny-cats", item.id)
        assertEquals("Funny cats", item.title)
        assertEquals("3:21", item.duration)
        val json = """{"ua":{"mp4":{"360":{"url":"https://r/360.mp4"},"720":{"url":"https://r/720.mp4"}}}}"""
        assertEquals(listOf("https://r/720.mp4", "https://r/360.mp4"), rumbleMp4Urls(json))
        assertTrue(rumbleMp4Urls("""{"u":{}}""").isEmpty())
    }

    @Test
    fun odyseeAndDailymotionAndVimeo() {
        val claim = "a".repeat(40)
        val resolved = """{"result":{"lbry://vid#$claim":{"claim_id":"$claim","name":"vid","value":{"title":"My video",
            "thumbnail":{"url":"https://t/x.jpg"},"video":{"duration":61}},"signing_channel":{"name":"@chan","value":{"title":"Chan"}}}}}"""
        val o = parseOdyseeResolve(resolved).single()
        assertEquals("$claim:vid", o.id)
        assertEquals("1:01", o.duration)
        assertEquals("Chan", o.uploader)
        assertEquals("https://player.odycdn.com/api/v3/streams/free/vid/$claim/abcdef.mp4", odyseeStreamUrl("vid", claim, "abcdef123"))
        val d = parseDailymotion("""{"list":[{"id":"x8abc12","title":"T","owner.screenname":"Owner","thumbnail_360_url":"https://d/t.jpg","duration":90}]}""").single()
        assertEquals("Owner", d.uploader)
        assertEquals("https://www.dailymotion.com/video/x8abc12", d.pageUrl)
    }

    @Test
    fun keylessPexelsPixabayVimeoReaders() {
        val pexelsHtml = """<a href="/video/learning-solar-system-7605272/"><img src="https://images.pexels.com/videos/7605272/x.jpeg"></a>
            <a href="/video/learning-solar-system-7605272/">dup</a><a href="/search/videos/space/">tag</a>"""
        val pi = parsePexelsPage(pexelsHtml).single()
        assertEquals("learning-solar-system-7605272", pi.id)
        assertEquals("Learning solar system", pi.title)
        val pexelsVideoPage = """{"src":"https:\/\/videos.pexels.com\/video-files\/7605272\/7605272-uhd_2560_1440_30fps.mp4"}
            <source src="https://videos.pexels.com/video-files/7605272/7605272-hd_1280_720_30fps.mp4">"""
        assertEquals(
            "https://videos.pexels.com/video-files/7605272/7605272-hd_1280_720_30fps.mp4",
            extractPexelsMp4(pexelsVideoPage).first()
        )
        val px = parsePixabayPage("""<a href="/videos/sea-waves-12345/"><img data-src="https://cdn.pixabay.com/t.jpg"></a>""").single()
        assertEquals("Sea waves", px.title)
        assertEquals("https://cdn.pixabay.com/t.jpg", px.thumbnailUrl)
        val pixPage = """"https://cdn.pixabay.com/video/2021/04/23/1-large.mp4" "https://cdn.pixabay.com/video/2021/04/23/1-medium.mp4" """
        assertTrue(extractPixabayMp4(pixPage).first().endsWith("1-medium.mp4"))
        assertEquals(listOf("123456789", "7654321"), parseVimeoIds("""<a href="/123456789">a</a><a href="https://vimeo.com/channels/staffpicks/7654321">b</a><a href="/about">c</a>"""))
        val v = parseVimeoOembed("""{"title":"Film","author_name":"Dir","thumbnail_url":"https://i.vimeocdn.com/x.jpg","duration":75}""", "123456789")!!
        assertEquals("1:15", v.duration)
        assertTrue(parseVimeoOembed("""{"title":""}""", "1") == null)
    }

    @Test
    fun webPlayerUrlsStayOnTheirOwnSite() {
        assertEquals("https://www.dailymotion.com/embed/video/x8abc12?autoplay=1", dailymotionEmbed("x8abc12"))
        assertEquals("https://player.vimeo.com/video/123456?autoplay=1", vimeoEmbed("123456"))
        assertEquals("https://rumble.com/embed/v5abcd/", rumbleEmbed("v5abcd"))
        assertEquals("https://odysee.com/$/embed/vid/${"a".repeat(40)}", odyseeEmbed("vid", "a".repeat(40)))
        assertEquals("https://diode.zone/videos/embed/6a1d7d3c-1111-4222-8333-444455556666?autoplay=1",
            peerTubeEmbed("diode.zone", "6a1d7d3c-1111-4222-8333-444455556666"))
        val m = DailymotionSource().resolve("x8abc12")
        assertTrue(m.urls.isEmpty())
        assertEquals(dailymotionEmbed("x8abc12"), m.embedUrl)
        assertEquals(dailymotionEmbed("x8abc12"), m.url)
        assertEquals(vimeoEmbed("123456"), VimeoWebSource().resolve("123456").embedUrl)
    }
}
