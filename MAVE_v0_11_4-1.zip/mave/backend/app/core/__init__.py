"""Cross-cutting infrastructure: configuration, security, logging, rate limiting, caching, metrics, network guard."""
